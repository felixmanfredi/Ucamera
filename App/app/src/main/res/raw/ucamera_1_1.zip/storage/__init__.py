from .models import GenericData, DeviceInfo, RecordingInfo
from .storage_manager import StorageManagerInterface, CompositeStorageManagerInterface
from .file_system_sm import FileSystemStorageManager

def create_storage(name: str, **init_params)-> 'StorageManagerInterface':
    if name == "composite":
        components: list['StorageManagerInterface'] = []
        for c in init_params.get("components", []):
            components.append(create_storage(c['name'], **c["config"]))
        return CompositeStorageManagerInterface(components)
    elif name == "File System":
        return FileSystemStorageManager(**init_params)
    else:
        raise ValueError(f"Not Supported Storage {name}")
