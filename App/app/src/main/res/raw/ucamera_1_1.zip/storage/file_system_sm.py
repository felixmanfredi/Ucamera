import io
import json
import os
import shutil
import threading
import warnings
import piexif
import diskcache as dc
from copy import deepcopy
from datetime import datetime
from typing import Optional
from PIL import Image
from storage import GenericData
from storage import StorageManagerInterface
from storage import cache
from storage.models import Dataset, DataInfo, DeviceInfo, RecordingInfo
from utils.constants import DatasetType
from utils import helper


class FileSystemStorageManager(StorageManagerInterface):

    _BACKUP_DIR="debug/storage/"

    def __init__(self, path: str):
      
        path = os.path.normpath(path)
            
        self.__path = path
        self.__cache = dc.Cache(os.path.join(self._BACKUP_DIR,".cache"), disk=cache.CustomDiskManager, size_limit=2**29) # 500 MB
        self.__cache.clear() # Remove obsolete files
        self.__datasets: dict[int, Dataset] = {}
        self.__lock = threading.Lock()  # TODO: Check if exists a more efficient mechanism to access shared data like Java ConcurrentHashMap
        self.__last_id = -1
        self.__load_datasets()
    
    @property
    def root_folder(self):
        path = os.path.join(self.__path,"")  # Add / to the end
        if not os.path.exists("/dev/sda1"):
            return self._BACKUP_DIR
        return self.__path

    def __load_datasets(self):
        for dataset_id in os.listdir(self.root_folder):
            # Every dataset is associated to a directory
            dataset_folder = os.path.join(self.root_folder, dataset_id)
            dataset_json = os.path.join(dataset_folder, "dataset.json")
            if os.path.isdir(dataset_folder) and os.path.isfile(dataset_json):
                #Cache does not contain dataset.json file and it is not parsed
                try:
                    with open(dataset_json, "r") as f:
                        dataset_info = json.load(f)
                    dataset_type = DatasetType(dataset_info.get("type"))
                    supported_exts = DatasetType.get_supported_formats(dataset_type)
                    data_list = {}
                
                    for root, _, filenames in os.walk(dataset_folder):
                        for file_name in filenames:
                            # Check Extension according to dataset type in order to load only data files ignoring the other
                            # ones (e.g. dataset.json) -> To Change if data is saved as json!
                            if file_name.lower().endswith(supported_exts):
                                file_path = os.path.join(root, file_name)
                                file_stat = os.stat(file_path)
                                name, ext = os.path.splitext(file_name) # extension could be empty
                                info = DataInfo(
                                    name=name,
                                    format=ext.lstrip("."), # Remove possible point that starting the extension
                                    size=file_stat.st_size, # Bytes
                                    created_at=datetime.fromtimestamp(file_stat.st_ctime).isoformat()
                                )
                                data_list[name] = info
                    did = int(dataset_id)
                    device_info = dataset_info.get("device")
                    rec_info = dataset_info.get("recording_info")
                    dataset = Dataset(
                        dataset_id=did,
                        name=dataset_info.get("name"),
                        dataset_type=dataset_type,
                        device_info=DeviceInfo(**device_info) if device_info is not None else None,
                        recording_info=RecordingInfo(**rec_info) if rec_info is not None else None,
                        description=dataset_info.get("description"),
                        created_at=dataset_info.get("created_at"),
                        updated_at=dataset_info.get("updated_at"),
                        completed=dataset_info.get("completed"),
                        data=data_list,
                        issues_messages=dataset_info.get("issues")
                    ) # items field is set to len(data_list)
                    if num_items := dataset_info.get("items"):
                        # Check if json dataset descriptor contains a different number of items and force json updating
                        if num_items != len(data_list):
                            warnings.warn(f"Number of items in Dataset Descriptor does not match with number of items({num_items}) in Dataset folder ({len(data_list)}).")
                            # Update dataset descriptor file
                            dataset.add_issue(f"Mismatch detected: Updating JSON descriptor to match the actual number of items in the Dataset folder.")
                            dataset.updated_at = datetime.now().isoformat()
                            with open(dataset_json, "w") as f:
                                json.dump(dataset.as_dict(), fp=f)
                    self.__datasets[did] = dataset
                    self.__last_id = max(self.__last_id, did)
                except (Exception,) as e:
                    print(f"Error during load dataset file {dataset_json} dataset id {str(dataset_id)}: {str(e)}")
                    self.__last_id = max(self.__last_id, int(dataset_id))
                
    @staticmethod
    def _read_data(dataset_folder: str, dataset_type: DatasetType, data_info: DataInfo) -> Optional[GenericData]:
        """
        Handle reading according to type and format. If image we read metadata from exif.
        If reading fails return None
        """
        data_path = os.path.join(dataset_folder, f"{data_info.name}.{data_info.format}")
        if os.path.isfile(data_path):
            if dataset_type == DatasetType.PHOTO:
                img = Image.open(data_path)
                load_params = {} # Additional params to load img to BytesIO
                metadata = {}
                # img.getexif() return Exif object but several key-values are not human-readable
                # img.info.get("exif") return binary exif data that ca be read by other libraries
                exif_bytes = img.info.get("exif", None)
                if exif_bytes:
                    load_params["exif"] = exif_bytes # In this way, we include also exif data to the content
                    exif_dict = piexif.load(exif_bytes)
                    for ifd in exif_dict:  # IFD = Image File Descriptor load by piexif
                        if exif_dict[ifd]:
                            for tag, value in exif_dict[ifd].items():
                                tag_name = piexif.TAGS[ifd][tag]["name"]
                                metadata[tag_name] = value
                    """
                    Alternative way to read exif:
                    with exiftool.ExifTool() as et:
                        metadata = et.get_metadata(data_path)
                    """
                byte_io = io.BytesIO()
                # Expected format by PIL could be different from extension name [e.g. JPEG != JPG], but we save
                # it as extension so we have to retrieve  with PIL the format name by extension.
                # Since image exist we can suppose that format is right
                img.save(byte_io, format=Image.EXTENSION[f".{data_info.format.lower()}"], **load_params)
                return GenericData(
                    name=data_info.name,
                    content_format=data_info.format,
                    content=byte_io.getvalue(),
                    created_at=data_info.created_at,
                    metadata=metadata
                )
            elif dataset_type == DatasetType.POINT_CLOUD:
                warnings.warn("Not implemented yet.")
                return None
        return None

    @staticmethod
    def _write_data(dataset_folder: str, dataset_type: DatasetType, data: GenericData):
        """
        Handle saving according to type and format. If image we add metadata to exif. Raise an error if fails
        """
        data_path = os.path.join(dataset_folder, f"{data.name}.{data.format}")
        if dataset_type == DatasetType.PHOTO:
            img = Image.open(io.BytesIO(data.content))
            # Attention: Content could not contain exif information if it was not passed
            exif_bytes = img.info.get("exif", None)
            exif_dict = piexif.load(exif_bytes) if exif_bytes else {} # Load previous metadata contained in exif to avoid complete override of these data
            for key, value in data.metadata.items():
                res = helper.find_exif_tag(key)
                if res:
                    if res[0] not in exif_dict:
                        # To avoid errors when dictionary is empty
                        exif_dict[res[0]] = {}
                    exif_dict[res[0]][res[1]] = value
            # We could to avoid format specification since we specify in data_path the extension
            f = Image.EXTENSION[f".{data.format.lower()}"]
            try:
                # At the moment it raises an error if fails to write image with or without EXIF to delegate handling to invoker (e.g. add issue message to dataset).
                img.save(data_path, format=f, exif=piexif.dump(exif_dict))
            except (Exception,) as e1:
                print(f"Error during writing attempt of {data.name} with EXIF metadata: {str(e1)}. Trying without EXIF metadata.")
                try:
                    img.save(data_path, format=f)
                except (Exception,) as e2:
                    print(f"Error during writing attempt of {data.name} without EXIF metadata: {str(e2)}.")
                    raise IOError(f"Error during writing attempt of {data.name}") from e2
                raise Warning(f"Image {data.name} was written but without EXIF metadata.") from e1
            """
            Alternative way to write exif:
            with exiftool.ExifTool() as et:
                et.set_tags(data_path, tags=data.metadata, params=["-P", "-overwrite_original"]) # -P ->  Preserve file modification date/time
            """
        elif dataset_type == DatasetType.POINT_CLOUD:
            warnings.warn("Not implemented yet.")

    def current_available_datasets(self) -> dict[int, Dataset]:
        with self.__lock:
            return deepcopy(self.__datasets) # We return a copy to avoid ambiguities in datasets representation

    def get_dataset_snapshot(self, dataset_id: int) -> Dataset:
        with self.__lock:
            if dataset_id not in self.__datasets:
                raise ValueError(f"Dataset with id {dataset_id} not found.")
            return deepcopy(self.__datasets[dataset_id]) # We return a copy to avoid ambiguities in datasets representation

    def create_dataset(self, dataset_name: str, dataset_type: DatasetType, device: DeviceInfo, rec_interval: float,
                       description: str = None) -> int:
        new_dataset_id = self.__last_id+1
        
        assert new_dataset_id not in self.__datasets, "Dataset ID already exists."
        dataset_folder = os.path.join(self.root_folder, str(new_dataset_id))
        
        try:
            os.mkdir(dataset_folder)
        except (Exception,) as e:
            # Throws exceptions if the folder already exists, if the parent does not exist or if permissions are denied.
            raise IOError(e) from e
        
        dataset = Dataset(new_dataset_id, dataset_name, dataset_type, device, RecordingInfo(rec_interval, 0), description)
        
        try:
            with open(os.path.join(dataset_folder, "dataset.json"), "w") as f:
                json.dump(dataset.as_dict(), fp=f)
        except (Exception,) as e:
            shutil.rmtree(dataset_folder)
            raise IOError(f"Error during creation of new dataset.") from e
        self.__datasets[new_dataset_id] = dataset
        self.__last_id = new_dataset_id
       
        return new_dataset_id

    def update_dataset_description(self, dataset_id: int, new_description: str):
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                dataset.description = new_description
                dataset.updated_at = datetime.now().isoformat()
                with open(os.path.join(self.root_folder, str(dataset_id), "dataset.json"), "w") as f:
                    json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")

    def update_dataset_name(self, dataset_id: int, new_name: str):
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                dataset.name = new_name
                dataset.updated_at = datetime.now().isoformat()
                with open(os.path.join(self.root_folder, str(dataset_id), "dataset.json"), "w") as f:
                    json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")

    def add_issue_messages(self, dataset_id: int, *issue_messages: str):
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                for msg in issue_messages:
                    dataset.add_issue(msg)
                dataset.updated_at = datetime.now().isoformat()
                with open(os.path.join(self.root_folder, str(dataset_id), "dataset.json"), "w") as f:
                    json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")

    def update_duration(self, dataset_id: int, duration: float):
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                dataset.set_recording_duration(duration)
                dataset.updated_at = datetime.now().isoformat()
                with open(os.path.join(self.root_folder, str(dataset_id), "dataset.json"), "w") as f:
                    json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")

    def close_dataset_acquisition(self, dataset_id: int, duration: float):
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                if dataset.completed:
                    raise RuntimeError("Dataset acquisition is completed. Cannot close again.")
                dataset.completed = True
                dataset.set_recording_duration(duration)
                dataset.updated_at = datetime.now().isoformat()
                with open(os.path.join(self.root_folder, str(dataset_id), "dataset.json"), "w") as f:
                    json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")

    def delete_dataset(self, dataset_id: int):
        with self.__lock:
            self.__datasets.pop(dataset_id, None)
            dataset_folder = os.path.join(self.root_folder, str(dataset_id))
            if os.path.isdir(dataset_folder):
                # os.rmdir does not remove full folder
                shutil.rmtree(dataset_folder)

    def save_data(self, dataset_id: int, data: GenericData):
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                if dataset.completed:
                    raise RuntimeError("Dataset acquisition is completed. Cannot save new data.")
                if dataset.contains_data(data.name):
                    raise ValueError(f"Data with name {data.name} already exists in dataset with id {dataset_id}.")
                dataset_folder = os.path.join(self.root_folder, str(dataset_id))
                try:
                    FileSystemStorageManager._write_data(dataset_folder, dataset.type, data)
                except (Exception,) as e:
                    raise IOError(f"Error during writing attempt of {data.name}: {str(e)}") from e
                dataset.put_data(data.name, data)
                dataset.items = dataset.items + 1
                dataset.updated_at = datetime.now().isoformat()
                with open(os.path.join(dataset_folder, "dataset.json"), "w") as f:
                    json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")

    def get_all_data(self, dataset_id: int) -> list[GenericData]:
        res = []
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                dataset_folder = os.path.join(self.root_folder, str(dataset_id))
                for data_info in dataset.data:
                    data_item = FileSystemStorageManager._read_data(dataset_folder, dataset.type, data_info)
                    if data_item:
                        res.append(data_item)
                    else:
                        # It should not happen, but in this case we should update dataset representation
                        dataset.remove_data(data_info.name) # This is not a concurrent modification as dataset.data return a copy values
        return res

    def get_data(self, dataset_id: int, data_name: str) -> GenericData:
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset and dataset.contains_data(data_name):
                dataset_folder = os.path.join(self.root_folder, str(dataset_id))
                data_info = dataset.get_data(data_name)
                data_item = FileSystemStorageManager._read_data(dataset_folder, dataset.type, data_info)
                if data_item:
                    return data_item
                else:
                    # It should not happen, but in this case we should update dataset representation
                    dataset.remove_data(data_info.name)
                    raise ValueError(f"Data with name {data_name} not found in dataset with id {dataset_id}.")
            else:
                raise ValueError(
                    f"Data with name {data_name} not found in dataset with id {dataset_id}." if dataset else
                    f"Dataset with id {dataset_id} not found."
                )

    def remove_data(self, dataset_id: int, data_name: str):
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                dataset_folder = os.path.join(self.root_folder, str(dataset_id))
                if dataset.contains_data(data_name):
                    data_info = dataset.get_data(data_name)
                    data_file = os.path.join(dataset_folder, f"{data_name}.{data_info.format}")
                    if os.path.isdir(dataset_folder) and os.path.isfile(data_file):
                        os.remove(data_file)
                    dataset.remove_data(data_name)
                    dataset.items = dataset.items - 1
                    dataset.updated_at = datetime.now().isoformat()
                    with open(os.path.join( "dataset.json"), "w") as f:
                        json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")


    def remove_all_data(self, dataset_id: int):
        """
        Remove all data from dataset, but not dataset itself.
        """
        with self.__lock:
            dataset = self.__datasets.get(dataset_id)
            if dataset:
                dataset_folder = os.path.join(self.root_folder, str(dataset_id))
                dataset_data = dataset.data
                if dataset_data:
                    for data_info in dataset_data:
                        data_file = os.path.join(dataset_folder, f"{data_info.name}.{data_info.format}")
                        if os.path.isdir(dataset_folder) and os.path.isfile(data_file):
                            os.remove(data_file)
                        dataset.remove_data(data_info.name)  # This is not a concurrent modification as dataset.data return a copy values
                        dataset.items = dataset.items - 1
                    dataset.updated_at = datetime.now().isoformat()  # Dataset is not empty so we should update time
                    with open(os.path.join("dataset.json"), "w") as f:
                        json.dump(dataset.as_dict(), fp=f)
            else:
                raise ValueError(f"Dataset with id {dataset_id} not found.")

    def get_used_storage_space(self):
        """
        :return: the space effectively occupied in the storage device in bytes
        """
        with self.__lock:
            total_size = 0
            for dir_path, _, file_names in os.walk(self.root_folder):
                # os.walk iterates on every subdirectory
                for f in file_names:
                    fp = os.path.join(dir_path, f)
                    total_size += os.path.getsize(fp)
            return total_size

    def get_free_storage_space(self):
        """
        :return: The space available in the storage device in bytes
        """
        _,_,free = shutil.disk_usage(self.root_folder)
        return free

    def get_dataset_archive_path(self, dataset_id: int):
        key = f"{dataset_id}.zip"
        value = self.__cache.get(key)
        if value is None:
            #Try to create zip archive
            with self.__lock:
                dataset = self.__datasets.get(dataset_id)
                if dataset:
                    #if not dataset.completed:
                    #    raise RuntimeError("Dataset acquisition is running. Please try again later.")
                    dataset_folder = os.path.join(self.root_folder, str(dataset_id))
                    filepath = shutil.make_archive(base_name=os.path.join(self.__cache.directory, str(dataset_id)),
                                                   format="zip", root_dir=dataset_folder)
                    self.__cache.set(key, filepath, expire=600)  # Expire after ten minutes - TODO: Check how works expiration
                    return filepath
                else:
                    raise ValueError(f"Dataset with id {dataset_id} not found.")
        else:
            res = value[0] if isinstance(value, tuple) else value
            if os.path.exists(res) and os.path.isfile(res):
                return res
            else:
                raise ValueError("Not Accessible File")
