from datetime import datetime
from typing import Any, Optional
from utils.constants import DatasetType
from collections import namedtuple

DataInfo = namedtuple("DataInfo", ["name", "format", "size", "created_at"])  # Or DataView
DeviceInfo = namedtuple("DeviceInfo", ["name", "settings"])  # Immutable data
# TODO: Save camera lights and flash settings as Exif if they could not be changed during an acquisition
RecordingInfo = namedtuple("RecordingInfo", ["recording_interval", "recording_duration"])

class GenericData:

	def __init__(self, name: str, content_format: str, content: bytes, created_at: str = None,
				 metadata: dict[str, Any] = None):
		self.__name = name
		self.__format = content_format
		self.__content = content
		self.__size = len(content)
		self.__created_at = created_at if created_at else datetime.now().isoformat()
		self.__metadata = metadata if metadata else {}

	@property
	def name(self) -> str:
		return self.__name

	@property
	def format(self) -> str:
		return self.__format

	@property
	def content(self) -> bytes:
		return self.__content

	@property
	def size(self) -> int:
		return self.__size

	@property
	def creation_date(self) -> str:
		return self.__created_at

	@property
	def metadata(self) -> dict[str, Any]:
		return self.__metadata

	def put_metadata(self, property_name: str, value: Any):
		"""
		Add new metadata property or update existing one with new value.
		"""
		self.__metadata[property_name] = value

	def remove_metadata(self, property_name: str):
		del self.__metadata[property_name]

	def as_data_info(self):
		return DataInfo(self.__name, self.__format, self.__size, self.__created_at)


class Dataset:

	def __init__(self, dataset_id: int, name: str, dataset_type: DatasetType, device_info: DeviceInfo,
				 recording_info: RecordingInfo, description: str = None, items: Optional[int] = None,
				 created_at: Optional[str] = None, updated_at: Optional[str] = None, completed: bool = False,
				 data: dict[str, DataInfo] = None, issues_messages: list[str] = None):
		self._dataset_id: int = dataset_id
		self._name: str = name
		self._type: DatasetType = dataset_type
		self._device: dict = device_info._asdict() if device_info else {}  # To save it in json as object and not as list
		self._recording_info: dict= recording_info._asdict() if recording_info else {}
		self._description: str = description
		self._created_at: str = created_at if created_at else datetime.now().isoformat()
		self._updated_at: str = updated_at if updated_at else self._created_at
		self._data: dict[str, DataInfo] = data if data else {}
		self._items: int = items if items else len(self._data)
		self._issues: list[str] = issues_messages if issues_messages else []
		self._completed: bool = completed

	@property
	def dataset_id(self) -> int:
		return self._dataset_id

	@property
	def name(self) -> str:
		return self._name

	@name.setter
	def name(self, name: str):
		self._name = name

	@property
	def type(self) -> DatasetType:
		return self._type

	@property
	def description(self) -> str:
		return self._description

	@description.setter
	def description(self, description: str):
		self._description = description

	@property
	def created_at(self) -> str:
		return self._created_at

	@property
	def updated_at(self) -> str:
		return self._updated_at

	@updated_at.setter
	def updated_at(self, updated_at: str):
		self._updated_at = updated_at

	@property
	def recoding_info(self) -> RecordingInfo:
		return RecordingInfo(**self._recording_info)

	def set_recording_duration(self, duration:float):
		self._recording_info["recording_duration"] = duration

	@property
	def acquisition_device(self) -> DeviceInfo:
		return DeviceInfo(**self._device)

	@property
	def data(self) -> list[DataInfo]:
		return list(self._data.values())

	@property
	def completed(self) -> bool:
		return self._completed

	@completed.setter
	def completed(self, value: bool):
		self._completed = value

	@property
	def items(self) -> int:
		return self._items

	@items.setter
	def items(self, value: int):
		self._items = value

	@property
	def issues_messages(self) -> list[str]:
		return self._issues

	def contains_data(self, name: str) -> bool:
		return name in self._data

	def put_data(self, name: str, data: GenericData):
		self._data[name] = data.as_data_info()

	def get_data(self, name: str) -> DataInfo:
		return self._data[name]

	def remove_data(self, name: str):
		if name in self._data:
			del self._data[name]

	def add_issue(self, message: str):
		self._issues.append(message)

	def remove_issue(self, message: str):
		if message in self._issues:
			self._issues.remove(message)

	def as_dict(self):
		"""Returns the dataset as a dictionary, automatically excluding specific fields."""
		exclude_fields = {"_data"}  # Set of fields to exclude
		return {
			key.lstrip("_"): value  # Removes the '__' prefix from private names
			for key, value in self.__dict__.items()
			if key not in exclude_fields
		}
