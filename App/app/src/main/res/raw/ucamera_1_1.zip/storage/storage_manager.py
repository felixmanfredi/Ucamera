from abc import ABCMeta, abstractmethod
from storage.models import GenericData, Dataset, DeviceInfo, RecordingInfo
from utils.constants import DatasetType


class StorageManagerInterface(metaclass=ABCMeta):

    @abstractmethod
    def current_available_datasets(self) -> dict[int, Dataset]:
        raise NotImplementedError("Getting Available Datasets Method not implemented")

    @abstractmethod
    def get_dataset_snapshot(self, dataset_id:int) -> Dataset:
        """
        Returns a snapshot representation of dataset identified by dataset_id.
        """
        raise NotImplementedError("Getting Meta Info Method not implemented")

    @abstractmethod
    def create_dataset(self, dataset_name: str, dataset_type: DatasetType, device: DeviceInfo, rec_interval: float,
                       description: str = None) -> int:
        """
        Create new Dataset with given name, type and description.
        :return: ID of the created dataset.
        :raise: error if creation fails
        """
        raise NotImplementedError("Creating Dataset Method not implemented")

    @abstractmethod
    def update_dataset_name(self, dataset_id: int, new_name: str):
        raise NotImplementedError("Updating Dataset Name Method not implemented")

    @abstractmethod
    def update_dataset_description(self, dataset_id: int, new_description: str):
        raise NotImplementedError("Updating Dataset Description Method not implemented")

    @abstractmethod
    def add_issue_messages(self, dataset_id: int, *issue_messages: str):
        raise NotImplementedError("Adding Issue Message Method not implemented")

    @abstractmethod
    def update_duration(self, dataset_id: int, duration: float):
        raise NotImplementedError("Updating Duration Method not implemented")

    @abstractmethod
    def close_dataset_acquisition(self, dataset_id: int, duration: float):
        raise NotImplementedError("Closing Dataset Acquisition Method not implemented")

    @abstractmethod
    def delete_dataset(self, dataset_id: int):
        raise NotImplementedError("Deleting Dataset Method not implemented")

    @abstractmethod
    def save_data(self, dataset_id: int, data: GenericData):
        raise NotImplementedError("Saving Data Method not implemented")

    @abstractmethod
    def get_all_data(self, dataset_id: int) -> list[GenericData]:
        raise NotImplementedError("Getting All Data Method not implemented")

    @abstractmethod
    def get_data(self, dataset_id:int, data_name: str) -> GenericData:
        raise NotImplementedError("Getting Data Method not implemented")

    @abstractmethod
    def remove_data(self, dataset_id:int, data_name: str):
        raise NotImplementedError("Removing Data Method not implemented")

    @abstractmethod
    def remove_all_data(self, dataset_id: int):
        raise (NotImplementedError("Removing All Data Method not implemented"))

    @abstractmethod
    def get_free_storage_space(self):
        raise NotImplementedError("Getting Free Storage Space Method not implemented")

    @abstractmethod
    def get_used_storage_space(self):
        raise NotImplementedError("Getting Used Storage Space Method not implemented")

    @abstractmethod
    def get_dataset_archive_path(self, dataset_id: int):
        raise NotImplementedError("Creating Archive Method not implemented")


class CompositeStorageManagerInterface(StorageManagerInterface):

    # Composite definition to save same data to more storage service at same time

    """
    TODO: This class should handle the ID of the dataset by ensuring a unique value with respect to that of the
     subcomponents. One could keep track of a mapping or simply concatenate the ids assigned by the subcomponents.
     However, the main problem to be handled is retrieving the associations between the different representations
     of the same dataset during reloading. One solution might be to introduce a special “unique” field (e.g. name)
     in the metadata of the dataset in order to easily recognise the various associations between the different ids.
    """

    def __init__(self, components: list[StorageManagerInterface]):
        self.__components = components
        self.__datasets_id = {}

    def create_dataset(self, dataset_name: str, dataset_type: DatasetType, device: DeviceInfo, rec_interval: float,
                       description: str = None)-> int:
        #TODO: Handle ID
        dataset_id = []
        for component in self.__components:
            did = component.create_dataset(dataset_name, dataset_type, device, rec_interval, description)
            dataset_id.append(did)
        return sum(dataset_id) # TODO

    def update_dataset_description(self, dataset_id: int, new_description: str):
        #TODO: Handle ID
        for component in self.__components:
            component.update_dataset_description(dataset_id, new_description)

    def update_dataset_name(self, dataset_id: int, new_name: str):
        # TODO: Handle ID
        for component in self.__components:
            component.update_dataset_name(dataset_id, new_name)

    def add_issue_messages(self, dataset_id: int, *issue_messages: str):
        # TODO: Handle ID
        for component in self.__components:
            component.add_issue_messages(dataset_id, *issue_messages)

    def update_duration(self, dataset_id: int, duration: float):
        # TODO: Handle ID
        for component in self.__components:
            component.update_duration(dataset_id, duration)

    def close_dataset_acquisition(self, dataset_id: int, duration: float):
        # TODO: Handle ID
        for component in self.__components:
            component.close_dataset_acquisition(dataset_id, duration)

    def delete_dataset(self, dataset_id: int):
        #TODO: Handle ID
        for component in self.__components:
            component.delete_dataset(dataset_id)

    def save_data(self, dataset_id: int, data: GenericData):
        #TODO: Handle ID
        for component in self.__components:
            component.save_data(dataset_id, data)

    def current_available_datasets(self) -> dict[int, Dataset]:
        pass #TODO

    def get_dataset_snapshot(self, dataset_id: int) -> Dataset:
        pass #TODO

    def get_all_data(self, dataset_id: int) -> list[GenericData]:
        pass #TODO

    def get_data(self, dataset_id: int, data_name: str) -> GenericData:
        pass #TODO

    def get_free_storage_space(self):
        pass #TODO

    def get_used_storage_space(self):
        pass #TODO

    def remove_all_data(self, dataset_id: int):
        pass #TODO

    def remove_data(self, dataset_id: int, data_name: str):
        pass #TODO

    def get_dataset_archive_path(self, dataset_id: int):
        pass #TODO

