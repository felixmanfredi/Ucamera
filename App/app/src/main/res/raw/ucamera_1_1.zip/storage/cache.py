import os.path as op
import diskcache as dc

class CustomDiskManager(dc.Disk):

    """

    """
    def store(self, value, read, key=dc.UNKNOWN):
        """
        By default, Disk expects a key and a value and then automatically creates the file to store the value from them.
        However, the libraries used may save the output directly to a file.
        For greater flexibility, we delegate to the cache only the management of files already created. So if the
        library returns the value, we store it on a cached file and then invoke the set function, which in turn calls
        store passing the filename as the key and the full path as the value.

        However, if the value-key pair does not comply with this function, the default policy is invoked with the
        creation of the file.

        :param value: full_path
        :param read: IGNORED since binary object is already saved in the path indicated by value
        :param key: filename
        :return: (size, mode, filename, value) tuple for Cache table
        """
        if op.exists(value) and op.isfile(value):
            size = op.getsize(value)
            return size, dc.core.MODE_RAW, key, value  # During removal the filename is taken by querying the db
        else:
            super().store(value, read, key)
