"""
It exposes Factory to create Responses and Validator to validate, convert Requests
"""

#TODO: ADD MESSAGE STRUCTURES, FACTORY AND VALIDATORS - Could be moved in communication_manager

class RequestValidator:
    pass

from flask import jsonify

class ResponseFactory:
    """
    Class to create standardized JSON responses for Flask APIs.
    """
    
    @staticmethod
    def success(data=None, message=None):
        """
        Generates a success response with optional data.
        """
        response = {
            "status": "success",
            "message": message if message else []
        }
        if data:
            response["data"] = data
        
        return jsonify(response), 200
    
    @staticmethod
    def error(message=None, code=500):
        """
        Generates an error response with a custom message and HTTP status code.
        """
        response = {
            "status": "error",
            "message": message if message else [],
            "code": code
        }
        
        return jsonify(response), code
    
    @staticmethod
    def create_response(success: bool, *args):
        """
        Generates either a success or an error response based on the provided arguments.
        Expected arguments:
        - A boolean (mandatory): Determines success or error response.
        - One or more strings (optional): Messages for the response.
        - One or more data fields (optional): Dictionaries, lists, tuples, etc., to include in the response.
        """
        
        messages = []
        data_list = []
        
        for arg in args:
            if isinstance(arg, str):
                messages.append(arg)
            elif isinstance(arg, (dict, list, tuple)):
                data_list.append(arg)
        
        if success:
            return ResponseFactory.success(data_list if data_list else None, messages)
        else:
            return ResponseFactory.error(messages)
