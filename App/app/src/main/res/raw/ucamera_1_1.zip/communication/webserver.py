import io
import threading
from flask import Flask, request, send_file,Response
from communication.message import ResponseFactory
from flask_socketio import SocketIO
from communication import CommunicationManager
from core import MPECore
import mimetypes
import gevent

class FlaskCommunicationManager(CommunicationManager):
    """
    WebSocket/Rest Communication Manager developed using Flask
    """
    __app = Flask(__name__)
    __app.json.sort_keys = False
    socketio = SocketIO(__app, cors_allowed_origins="*", async_mode="gevent", path="/socket", transports=["websocket"],
                          logger=False, engineio_logger=False)

    def __init__(self, host: str, port: int, security_key: str, mpe_core: MPECore):
        """Initialize Flask app"""
        super().__init__(mpe_core)
        self.__host = host
        self.__port = port
        self._setup_routes()
        if security_key:
            self.__app.secret_key = security_key
        self.__lock = threading.Lock()
        self.__connected_clients = dict()
        self._setup_websockets()

    def _setup_websockets(self):
        """Define all the websockets for the API"""

        @self.socketio.on("connect")
        def on_connect(auth):
            """Called when a new client connects to the websocket"""
            sid = request.sid
            remote_addr = request.remote_addr
            with self.__lock:
                if len(self.__connected_clients) == 0:
                    self._mpe_core.register_status_observer(self.send_status)
                self.__connected_clients[sid] = {
                    "ip": remote_addr,
                }
                print(f"Client connected: {sid} with IP {remote_addr}")

        @self.socketio.on("disconnect")
        def on_disconnect(reason):
            """Called when a client disconnects from the websocket"""
            with self.__lock:
                sid = request.sid
                if sid in self.__connected_clients:
                    del self.__connected_clients[sid]
                    print(f"Client {sid} disconnected for reason: {reason}: ")
                if len(self.__connected_clients) == 0:
                    self._mpe_core.unregister_status_observer(self.send_status)


    def send_status(self, status_event: str, status_data: dict):
        """Send a status message to all connected clients"""
        #print(f"Sending status event {status_event} to {len(self.__connected_clients)} clients")
        self.socketio.emit(status_event, status_data)

    def _setup_routes(self):
        """Define all the routes for the API"""

        # Homepage route
        @self.__app.route("/")
        def homepage():
            """Returns a simple greeting message."""
            return "<h1 style='color: green;'>Hello World!</h1>"

        ### DATASET ROUTES
        @self.__app.route("/datasets/", methods=["GET"])
        def get_datasets():
            """Returns a JSON list of all available datasets of <type> with metadata."""
            try:
                datasets = self._mpe_core.get_datasets()
                return ResponseFactory.create_response(True, datasets)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        @self.__app.route("/datasets/<dataset_id>", methods=["GET"])
        def get_dataset(dataset_id):
            """Downloads the specified photogrammetric dataset as a ZIP archive."""
            try:
                zip_path = self._mpe_core.get_dataset(dataset_id)
                return send_file(
                    zip_path,
                    as_attachment=True,
                    download_name=f"{dataset_id}.zip",
                    mimetype="application/zip"
                )
            except (ValueError, FileNotFoundError) as e:
                return ResponseFactory.error(message = str(e))

        @self.__app.route("/datasets/start/", methods=["POST"])
        def start_new_acquisition():
            """Creates a new dataset with a given name, description, and interval."""
            try:
                data = request.get_json()
                datasetname = data.get("datasetname")
                description = data.get("description")
                interval = data.get("interval")
                # TODO Add Acquisition Type
                dataset_id = self._mpe_core.start_new_acquisition(datasetname, description, interval) # TODO Add Acquisition Type
                return ResponseFactory.create_response(True, f"New acquisition started.", {"dataset_id": dataset_id}) # TODO Here we can return dataset.as_dict
            except Exception as ex:
                return ResponseFactory.create_response(False, f"Error while starting new acquisition: {str(ex)}")

        @self.__app.route("/datasets/stop", methods=["PUT"])
        def stop_current_acquisition():
            """Stops the current acquisiton process."""
            try:
                self._mpe_core.stop_current_acquisition()
                return ResponseFactory.create_response(True, "Acquisition stopped.")
            except Exception as ex:
                return ResponseFactory.create_response(False, f"Error while stopping acquisition: {str(ex)}")

        # Get the list of files contained in the specified dataset
        @self.__app.route("/datasets/<dataset_id>/info", methods=["GET"])
        def get_dataset_info(dataset_id):
            """Returns a list of files from the specified path."""
            try:
                info = self._mpe_core.get_dataset_info(dataset_id)
                return ResponseFactory.create_response(True, info)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))
           

        ### CAMERA ROUTES
        @self.__app.route("/camera/settings", methods=["GET"])
        def get_camera_params():
            """Returns the current camera parameters."""
            try:
                camera_settings = self._mpe_core.get_camera_settings()
                return ResponseFactory.create_response(True, camera_settings)
            except Exception as ex:
                return ResponseFactory.create_response(False, {str(ex)})

        @self.__app.route("/camera/settings", methods=["PUT"])
        def set_camera_params():
            """Sets the camera parameters."""
            try:
                data = request.get_json()
                self._mpe_core.set_camera_settings(data)
                return ResponseFactory.create_response(True)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        @self.__app.route("/camera/capture", methods=["GET"])
        def capture_camera():
            try:
                image_data, extension = self._mpe_core.capture_camera()
                if image_data:
                    return send_file(
                        io.BytesIO(image_data),
                        mimetype=f"image/{extension}",
                        as_attachment=False
                    )
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        # Get the current lighting intensity
        @self.__app.route("/camera/lights", methods=["GET"])
        def get_lights():
            """Returns the current lighting intensity."""
            try:
                lights_params = self._mpe_core.get_camera_lights()
                return ResponseFactory.create_response(True, lights_params)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        # Set lighting intensity
        @self.__app.route("/camera/lights/", methods=["PUT"])
        def set_lights():
            """Sets the lighting intensity to the given percentage."""
            try:
                lights_params = request.get_json()
                self._mpe_core.set_camera_lights(**lights_params)
                return ResponseFactory.create_response(True)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        # Flash intensity routes
        @self.__app.route("/camera/flash", methods=["GET"])
        def get_flash():
            """Returns the current flash intensity."""
            try:
                flash = self._mpe_core.get_camera_flash()
                return ResponseFactory.create_response(True, flash)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        @self.__app.route("/camera/flash/", methods=["PUT"])
        def set_flash():
            """Sets the flash intensity to the given percentage."""
            try:
                flash_params = request.get_json()
                self._mpe_core.set_camera_flash(**flash_params)
                return ResponseFactory.create_response(True)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        def gen():
            while True:
                image_data, extension = self._mpe_core.preview_camera()
                mimetype = mimetypes.guess_type(f"a.{extension}")
                if image_data:
                    yield (b'--frame\r\n'
                    b'Content-Type: ' + mimetype[0].encode() + b'\r\n\r\n' +
                    image_data + b'\r\n')

                    gevent.sleep(0.4) # 0.04s = 40ms = 25 frames per second 

        @self.__app.route('/video')
        def video():
            return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=frame')
        
        @self.__app.route("/preview")
        def preview():
            """Returns a simple greeting message."""
            return "<img src='http://192.168.1.145:45032/video' width='100%'> "

        ### STEREOCAMERA ROUTES
        # TODO
        # Start, Stop, SavePointCloud, GetPointClouds: [list], GetPointCloud(name)


        ### PLUGINS ROUTES 

        # Get a list of available plugins
        @self.__app.route("/plugins", methods=["GET"])
        def get_plugins():
            """Returns a list of installed plugins."""
            try:
                plugins = self._mpe_core.get_plugins()
                return ResponseFactory.create_response(True, plugins)
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        # TODO Install, Disinstall, Enable, Disable, GetDetails: json (manifest file)

        ### SYSTEM ROUTES

        # Restart the system
        @self.__app.route("/system/restart", methods=["POST"])
        def restart():
            """Restarts the system."""
            try:
                self._mpe_core.restart()
                return ResponseFactory.create_response(True, "System restarted")
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

        # Reboot the system
        @self.__app.route("/system/reboot", methods=["POST"])
        def reboot():
            """Reboots the system."""
            try:
                self._mpe_core.reboot()
                return ResponseFactory.create_response(True, "Rebooting the system...")
            except Exception as ex:
                return ResponseFactory.create_response(False, str(ex))

    def run(self, debug=True):
        """Run the Flask app"""
        self.socketio.run(self.__app, host=self.__host, port=self.__port, debug=debug, use_reloader=False)

if __name__ == "__main__":
    from debug import MPECoreMock
    server = FlaskCommunicationManager(host="0.0.0.0", port=5000, security_key="your_key", mpe_core=MPECoreMock())
    server.run()