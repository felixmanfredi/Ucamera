from abc import ABCMeta, abstractmethod
from core import MPECore

class CommunicationManager(metaclass=ABCMeta):

    @abstractmethod
    def __init__(self, mpe: MPECore):
        self.__facade = mpe

    @abstractmethod
    def run(self, debug: bool):
        raise NotImplementedError

    @property
    def _mpe_core(self):
        return self.__facade