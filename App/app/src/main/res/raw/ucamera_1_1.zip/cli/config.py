import json
import os
from typing import Any

from cerberus import Validator


def __validate_path(field, value, error):
    if not os.path.exists(value):
        error(field, f"Path {value} does NOT exist!")

remote_schema = {
    'type': 'dict',
    'schema': {
        'host': {
            'type': 'string',
            'regex': '^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$',
            'required': True
        },
        'port': {
            'type': 'integer',
            'min': 1,
            'max': 65535,
            'required': True
        },
        'secret_key': {
            'type': 'string'
        }
    }
}

fs_schema = {
    "type": "dict",
    "schema": {
        "name": {
            "type": "string",
            "allowed": ["File System"],
            "required": True
        },
        "config": {
            "type": "dict",
            "schema": {
                'path': {
                    'type': 'string',
                    'required': True,
                    #'check_with': __validate_path
                },
            },
            "required": True
        }
    }
}

storages_schema = {
    'type': 'list',
    'schema': {
        'type': 'dict',  # Ensures each item in the list is a dictionary
        'oneof': [
            fs_schema,
        ]
    },
    'empty': False,
    'required': True
}
channels_schema = {
    'type': 'list',
    'schema': {
        'type': 'dict',
        'schema': {
            'name': {
                'type': 'string',
                'allowed': ['Flask']
            },
            'config': remote_schema
        }
    },
    'empty': False,
    'required': True
}

config_schema = {
    "plugins_folder":{
        'type': 'string',
        'check_with': __validate_path
    },
    "imaging_system": {
        'type': 'dict',
        'schema': {
            "camera": {
                'type': 'string',
                #'allowed': ["Arducam", "ILX-RF1"]
            },
            "stereocamera": {
                'type': 'string',
                #'allowed': ["ZED X One"]
            }
        },
        'empty': False
    },
    "location_system": {
        'type': 'string',
        #'allowed': ["PAUV", "GGA"],
        'required': True,
    }, # For plug-in components, only the name is sufficient, as the PluginManager performs runtime injection of the component identified by the name using the configurations specified in the plug-in.
    "storages": storages_schema,  # Suppose could have different mechanism to support composite saving of the data
    "channels": channels_schema  # Different Channel for different Front-End Apps
}


def load_config(config_path: str) -> dict[str, Any]:
    with open(config_path) as f:
        c = json.load(f)
        v = Validator(schema=config_schema)  # Case Sensitive
        if v.validate(c):
            return c
        else:
            print(v.errors)
            raise ValueError("Wrong Configuration File for {}".format(", ".join(v.errors)))


def save_config(config: dict, path:str):
    v = Validator(schema=config_schema)  # Case Sensitive
    if v.validate(config):
        with open(path, "w") as f:
            json.dump(config, fp=f) #TODO: If user cannot set all config parameters we can use prototype to set default values
    else:
        print(v.errors)
        raise ValueError("Wrong Configuration File for {}".format(", ".join(v.errors)))
