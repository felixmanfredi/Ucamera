import sys
import os
import config

cwd = os.path.dirname(__file__)
os.chdir(os.path.join(cwd, ".."))
sys.path.append(os.getcwd())

import argparse
import commands
from enum import StrEnum

class Command(StrEnum):
    RUN = "run"
    DEBUG = "debug"

parser = argparse.ArgumentParser()
subparsers = parser.add_subparsers(dest="command", required=True)

run_parser = subparsers.add_parser(Command.RUN)
run_parser.add_argument("-c", "--config", help="Path to JSON Config File", default='config.json')
run_parser.add_argument("-m", "--mock", action="store_true", help="Enable mock mode")

debug_parser = subparsers.add_parser(Command.DEBUG)
debug_parser.add_argument("-i", "--images_path", help="Path to Images Folder", default='tmp/images/image.jpg')
debug_parser.add_argument("-s", "--storage_path", help="Path to Storage Folder", default='tmp/storage')
debug_parser.add_argument("-ch", "--communication_host", help="Host for Communication Channel", default='127.0.0.1')
debug_parser.add_argument("-cp", "--communication_port", help="Port for Communication Channel", default=5000)


if __name__ == "__main__":
    args = parser.parse_args()
    cmd = getattr(commands, args.command, None)
    if cmd:
        if args.command == Command.RUN and args.mock:
            config.config_schema["imaging_system"]["schema"]["camera"]["allowed"].append("CameraMock")
            config.config_schema["location_system"]["allowed"].append("LocationSystemMock")
            print(config.config_schema)
        cmd(args)
    else:
        raise NotImplementedError(f"Command {args.command} not implemented")