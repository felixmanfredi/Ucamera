"""
CLI COMMANDS MODULE
"""
import argparse
import sys

import config
import signal
from communication import CommunicationManager
from communication import FlaskCommunicationManager
from core.mpe_core import MPECore
from core.plugin import PluginManager
from debug.camera_mock import CameraMock
from debug.location_system_mock import LocationSystemMock
from storage import FileSystemStorageManager


def build_facade(camera: str, stereocamera: str, location_system: str, storages_config: list[dict]) -> MPECore:
    builder = MPECore.Builder()
    if camera:
        builder.build_camera(camera)
    if stereocamera:
        builder.build_stereocamera(stereocamera)
    if location_system:
        builder.build_location_system(location_system)
    if storages_config:
        if len(storages_config) > 1:
            storage_params = {
                "components": storages_config
            }
            builder.build_storage("composite", **storage_params)
        else:
            builder.build_storage(storages_config[0]["name"], **storages_config[0]["config"])
    return builder.product


def build_communication_manager(name: str, configuration: dict, mpe_core: MPECore) -> CommunicationManager:
    if name == 'Flask':
        return FlaskCommunicationManager(configuration['host'], configuration['port'],
                                         configuration.get("secret_key", ""), mpe_core)
    else:
        raise ValueError("Unsupported Channel: {}".format(name))

def setup_signal_handler(signal_handler):
    if hasattr(signal, "SIGHUP"):  # SIGHUP is not available on Windows
        signal.signal(signal.SIGHUP, signal_handler)  # Handle parent process dead
    if hasattr(signal, "SIGINT"):
        signal.signal(signal.SIGINT, signal_handler)
    if hasattr(signal, "SIGTERM"):  # Ensure it exists on the platform
        signal.signal(signal.SIGTERM, signal_handler)

# Command Execution

def run(args: argparse.Namespace):
    configuration = config.load_config(args.config)
    PluginManager(plugins_root=configuration.get("plugins_folder", "plugins")) # Works without adding plugins_root to sys.path
    mpe = build_facade(configuration["imaging_system"].get("camera", ""),
                       configuration["imaging_system"].get("stereocamera", ""),
                       configuration.get("location_system", ""),
                       configuration.get("storages", []))

    def signal_handler(signum, frame):
        print(f"Handle {signum}")
        mpe.stop()
        #TODO: Add finalisation of communication_handler (e.g. to remove observer on status)
        sys.exit(0)

    try:
        mpe.start()
    except Exception as e:
        print(f"Error during MPE start: {str(e)}")
    finally:
        setup_signal_handler(signal_handler)
        for channel in configuration['channels']:
            ch = build_communication_manager(channel['name'], channel['config'], mpe)
            ch.run(debug=False)

def debug(args: argparse.Namespace):
    PluginManager(plugins_root="plugins")
    mpe = MPECore()
    mpe._camera =  CameraMock(args.images_path)
    mpe._location_system = LocationSystemMock()
    mpe._storage_manager = FileSystemStorageManager(args.storage_path)

    def signal_handler(signum, frame):
        print(f"Handle {signum}")
        mpe.stop()
        # TODO: Add finalisation of communication_handler (e.g. to remove observer on status)
        sys.exit(0)

    try:
        mpe.start()
    except Exception as e:
        print(f"Error during MPE start: {str(e)}")
    finally:
        setup_signal_handler(signal_handler)
        ch = build_communication_manager("Flask",
                                        {
                                            "host": args.communication_host,
                                            "port": args.communication_port,
                                        }, mpe)
        ch.run(debug=True)