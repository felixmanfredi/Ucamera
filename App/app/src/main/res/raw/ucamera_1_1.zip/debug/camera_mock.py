import os
import time
import threading
from devices import CameraInterface
from typing import Any, Callable

class CameraMock(CameraInterface):

    def __init__(self, image_path: str, bright=100, contrast=100, saturation=100, sharpness=100):
        super().__init__("camera_mock")
        self.image_path = image_path  # Path dell'immagine fissa
        self.settings = {
            "bright": bright,
            "contrast": contrast,
            "saturation": saturation,
            "sharpness": sharpness
        }
        self.__lights_value = 0
        self.__flash_value = 0
        self._is_recording = False
        self.recording_thread = None
        self.counter = 0
        print(f"CameraMock initialized with image: {image_path}")

    def start_service(self):
        print("CameraMock service started.")
        self._is_running = True
        return True

    def stop_service(self):
        print("CameraMock service stopped.")
        self._is_running = False

    def get_settings(self):
        return self.settings

    def set_settings(self, settings: dict[str, Any]):
        self.settings.update(settings)
        print(f"Settings updated: {self.settings}")

    def capture_image(self, callback: Callable[[str, bytes, str], None]):
        if os.path.exists(self.image_path):
            with open(self.image_path, "rb") as img_file:
                image_data = img_file.read()
            callback("nome", image_data, "jpg")
            print("Mock image captured and callback executed.")
        else:
            print("Error: Image file not found.")

    def start_recording(self, interval: float, callback: Callable[[str, bytes, str], None]):
        if self._is_recording:
            print("Recording is already running.")
            return
        
        if os.path.exists(self.image_path):
            with open(self.image_path, "rb") as img_file:
                image_data = img_file.read()

            self._is_recording = True
            print(f"Mock recording started with interval: {interval} seconds")

            def record():
                while self._is_recording:
                    self.counter += 1
                    image_name = f"image_{self.counter}"
                    callback(image_name, image_data, "jpg")
                    time.sleep(interval)

            self.recording_thread = threading.Thread(target=record, daemon=True)
            self.recording_thread.start()
        else:
            print("Error: mock image file not found. Recording NOT Started")
            return

    def stop_recording(self):
        if not self._is_recording:
            print("Recording is not running.")
            return
        
        self._is_recording = False
        self.counter = 0
        if self.recording_thread:
            self.recording_thread.join()
        print("Mock recording stopped.")

    def get_lights(self):
        return self.__lights_value

    def set_lights(self, **lights):
        self.__lights_value = lights

    def get_flash(self):
        return self.__flash_value

    def set_flash(self, **flash):
        self.__flash_value = flash
