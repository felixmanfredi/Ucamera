import socketio

sio = socketio.Client()

@sio.event
def connect():
    print("✅ Connected to the server!")

@sio.event
def disconnect():
    print("❌ Disconnected from the server!")

@sio.on("*")
def catch_all(event, data):
    if event == "location_status":
        print(f"🌍 Location update received: {data}")
    elif event == "board_status":
        format_data(data)
        print(f"🤖 Board status update received: {data}")
    else:
        print(f"🎯 Received event: {event} with data: {data}")

def format_data(data):
    def bytes_to_gb(value):
        return round(value / (1024 ** 3), 2)  # Convert bytes to GB with 2 decimal places

    if "free_ram" in data:
        data["free_ram"] = f"{bytes_to_gb(data['free_ram'])} GB"
    if "used_ram" in data:
        data["used_ram"] = f"{bytes_to_gb(data['used_ram'])} GB"
    if "free_disk" in data:
        data["free_disk"] = {key: f"{bytes_to_gb(value)} GB" for key, value in data["free_disk"].items()}
    if "used_disk" in data:
        data["used_disk"] = {key: f"{bytes_to_gb(value)} GB" for key, value in data["used_disk"].items()}

try:
    sio.connect("http://localhost:5000", socketio_path="/socket", transports=['websocket'])
    print("Waiting for events... press CTRL+C to exit.")
    sio.wait()  # Wait indefinitely for events
except KeyboardInterrupt:
    sio.disconnect()
except Exception as e:
    print(f"Error: {e}")