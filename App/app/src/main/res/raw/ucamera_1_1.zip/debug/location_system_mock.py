import random
import threading
import time
from datetime import datetime
from devices.location_system import LocationSystemInterface
from utils.constants import LatitudeDirection, LongitudeDirection, AltitudeDirection


class LocationSystemMock(LocationSystemInterface):

    def __init__(self):
        super().__init__()

    def init_service(self) -> bool:
        """Simulates the initialization of the service, returning True"""
        return True

    @staticmethod
    def _get_coordinates():
        """Returns random GPS coordinates within a realistic range."""
        latitude = random.uniform(-90.0, 90.0)
        longitude = random.uniform(-180.0, 180.0)
        return (latitude, LatitudeDirection.NORTH), (longitude, LongitudeDirection.EAST)

    @staticmethod
    def _get_altitude():
        """Returns a random altitude between -100 and 9000 meters"""
        return random.uniform(-100, 9000), AltitudeDirection.BSL

    def start_service(self):
        """
        Simulates the location service updating coordinates periodically.
        """
        self._is_running = self.init_service()

        def read_location_loop():
            while self._is_running:
                timestamp = datetime.now().timestamp()
                latitude, longitude = self._get_coordinates()
                altitude = self._get_altitude()
                self._update_coordinates(timestamp, latitude, longitude, altitude)
                time.sleep(1)  # Simulates a periodic update
        
        t = threading.Thread(target = read_location_loop)
        t.start()
        return True

    def stop_service(self):
        """Stops the location service. Simulates the termination of the service"""
        self._is_running = False
        print("MockLocationSystem: Service terminated.")

    def log(self):
        pass