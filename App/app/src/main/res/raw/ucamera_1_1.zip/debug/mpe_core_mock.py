from core import MPECore
from storage import DeviceInfo, RecordingInfo
from storage.models import Dataset
from utils.constants import DatasetType


class MPECoreMock(MPECore):


	def get_datasets(self):
		datasets = [
			Dataset(1, "Dataset A", DatasetType.PHOTO,
					DeviceInfo("Camera", settings=self.get_camera_settings()),
					RecordingInfo(5, 802),
					"Sample dataset A"),
			Dataset(2, "Dataset B", DatasetType.POINT_CLOUD,
					DeviceInfo("Stereocamera", settings=self.get_camera_settings()),
					RecordingInfo(15, 912),
					"Sample dataset B")
		]
		return [dataset.as_dict() for dataset in datasets]

	def get_dataset(self, dataset_id):
		return f"E:\Workspace\MASE\mpe-server\\tmp\{dataset_id}.zip" if dataset_id in ['1', '2'] else None
	
	def get_dataset_info(self, dataset_id):
		dataset = Dataset(1, "Dataset A", DatasetType.PHOTO,
						  DeviceInfo("Camera", settings=self.get_camera_settings()),
						  RecordingInfo(15, 1230),
						  "Sample dataset A")
		return dataset.as_dict()

	def start_new_acquisition(self, datasetname, description, interval):
		return f"mocked-{datasetname}-id"

	def stop_current_acquisition(self):
		return "Mock acquisition stopped"

	def restart(self):
		return "Mock system restarting"

	def reboot(self):
		return "Mock system rebooting"

	def get_camera_settings(self):
		return {"resolution": "1920x1080", "fps": 30, "exposure": "auto", "white_balance": "daylight", "iso": 200}

	def set_camera_settings(self, settings):
		return f"Mock camera settings updated: {settings}"

	def capture_camera(self):
		return "Mock image captured"

	def get_camera_lights(self):
		return {"intensity": "50%"}

	def set_camera_lights(self, intensity):
		return f"Mock lights set to {intensity}%"

	def get_camera_flash(self):
		return "Mock flash intensity: 0%"

	def set_camera_flash(self, intensity):
		return f"Mock flash set to {intensity}%"

	def get_plugins(self):
		return [
			{"id": 1, "name": "Camera Pro", "description": "High-resolution camera plugin", "type": "camera"},
			{"id": 2, "name": "GPS Tracker", "description": "Real-time GPS tracking plugin", "type": "localization"},
			{"id": 3, "name": "StereoCamera", "description": "ZED Camera", "type": "stereocamera"}
		]