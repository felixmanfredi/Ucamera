import unittest
from utils.helper import dd2dms

class TestDd2Dms(unittest.TestCase):
    """Unit tests for the dd2dms function"""

    def test_dd2dms(self):
        """Test conversion of decimal degrees to degrees, minutes, and seconds."""
        test_cases = [
            (0.0, (0, 0, 0.0)),
            (45.75, (45, 45, 0.0)),
            (-73.983, (-73, 58, 58.8)),
            (120.5, (120, 30, 0.0)),
            (-180.0, (-180, 0, 0.0)),
            (180.0, (180, 0, 0.0)),
            (15.1234, (15, 7, 24.24)),
            (-89.9999, (-89, 59, 59.64)),
        ]

        for decimal, expected in test_cases:
            with self.subTest(decimal=decimal):
                self.assertEqual(dd2dms(decimal), expected)

if __name__ == "__main__":
    unittest.main()
