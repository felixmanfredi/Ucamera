from enum import StrEnum, IntEnum
from typing import Tuple


class DeviceType(StrEnum):
    CAMERA = "camera"
    STEREOCAMERA = "stereocamera"
    LOCATION_SYSTEM = "location_system"


class DatasetType(StrEnum):
    PHOTO = "photo"
    POINT_CLOUD = "point_cloud"

    @classmethod
    def get_supported_formats(cls, dataset_type: 'DatasetType') -> Tuple[str]:
        """Return the list of supported file extensions for the dataset type."""
        mapping: dict['DatasetType', tuple] = {
            cls.PHOTO: ("jpg", "jpeg", "png", "tiff", "bmp"), # TODO: Check
            cls.POINT_CLOUD: ("pcd", "ply", "las", "xyz") # TODO: Check
        }
        return mapping.get(dataset_type, ())

class LatitudeDirection(StrEnum):
    NORTH = "N"
    SOUTH = "S"

class LongitudeDirection(StrEnum):
    EAST = "E"
    WEST = "W"

class AltitudeDirection(IntEnum):
    ASL = 0
    BSL = 1