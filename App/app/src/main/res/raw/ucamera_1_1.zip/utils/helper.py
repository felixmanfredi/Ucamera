import warnings
import piexif
from fractions import Fraction
from typing import Optional

def find_exif_tag(tag_name: str)-> Optional[tuple[str, int]]:
    """
    Search ID and Image File Descriptor (IDF) associated with a tag name iterating over all IDF definition
    (i.e. Image [Primary(0th)-Thumbnail(1st)], GPS, EXIF, INTEROP).
    Since Primary and Thumbnail IDF have same definition we only load and update the first one.
    :param tag_name: EXIF Tag Name
    :return: IDF (str), Tag ID (id) if tag_name is valid, otherwise None
    """
    ignore_tags = ["Image", "1st"] # Has same tag of 0th, but we consider only primary during loading and exporting
    for ifd in piexif.TAGS:
        if ifd not in ignore_tags:
            for tag_id, tag in piexif.TAGS[ifd].items():
                if tag["name"] == tag_name:
                    return ifd, tag_id
    warnings.warn(f"Unknown exif Tag: {tag_name}. Probably it is not a standard tag yet.")
    if tag_name.isdigit():
        warnings.warn("However it is a valid number. Try to add it to EXIF IDF.")
        return "Exif", int(tag_name)
    return None

def dd2dms(decimal_coord: float) -> tuple[int, int, float]:
    grade = int(decimal_coord)
    decimal_minutes = abs(decimal_coord - grade) * 60
    minutes = int(decimal_minutes)
    seconds = (decimal_minutes - minutes) * 60
    return grade, minutes, seconds

def dms2dd(degree: int, minutes: int, seconds: float) -> float:
    return degree + minutes/60 + seconds/3600

def float2rational(floating: float) -> tuple[int, int]:
    fraction = Fraction(floating).limit_denominator()
    return fraction.numerator, fraction.denominator



