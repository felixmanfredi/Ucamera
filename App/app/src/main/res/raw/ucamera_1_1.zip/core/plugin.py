import ast
import importlib.metadata as import_metadata
import importlib.util as import_util
import json
import os
import warnings
import zipfile
import zipimport
from types import ModuleType
from typing import Generic, TypeVar, Any, Optional

from packaging.requirements import Requirement
from pip import main as pip_main

from devices import CameraInterface, StereoCameraInterface, LocationSystemInterface
from utils.constants import DeviceType
from utils.mpe_typing import Singleton

_T = TypeVar("_T", CameraInterface, StereoCameraInterface, LocationSystemInterface) # can be only one of these types

class Plugin(Generic[_T]):

    def __init__(self,
                 version: str,
                 module: ModuleType,
                 dependencies: list[Requirement], # from Requirement we could obtain Distribution to access to effectively installed packed information
                 service_class_name: str,
                 **service_params):
        self.__module: ModuleType = module
        self.__dependencies: list[Requirement] = dependencies
        self.__version: str = version
        self.__service_class_name: str = service_class_name
        self.__service_params: dict[str, Any] = service_params
        self.__wrapped_service: Optional[_T] = None

    @property
    def version(self) -> str:
        return self.__version

    @property
    def dependencies(self) -> list[Requirement]:
        return self.__dependencies

    @property
    def service(self) -> Optional[_T]:
        return self.__wrapped_service

    @property
    def service_config(self) -> dict[str, Any]:
        return self.__service_params

    def wrapper_is_loaded(self) -> bool:
        return self.__wrapped_service is not None

    def _load_wrapper(self):
        wrapper_class = getattr(self.__module, self.__service_class_name)
        if not wrapper_class:
            raise AttributeError(f"Class {self.__service_class_name} not found in module {self.__module.__name__}.")
        self.__wrapped_service = wrapper_class(**self.__service_params)

    # TODO: Add other Plug-in functions


class PluginManager(metaclass=Singleton):

    def __init__(self, plugins_root: str):
        """
        Initialize the plugin manager, performing static analysis for all available plugins 
        in the predefined plugin directories.
        """
        self.__plugins_root = plugins_root
        self.__plugins = {
            DeviceType.CAMERA: {},
            DeviceType.STEREOCAMERA: {},
            DeviceType.LOCATION_SYSTEM: {}
        }
        for category in DeviceType:
            plugin_dir = os.path.join(self.__plugins_root, category)
            if not os.path.exists(plugin_dir):
                warnings.warn(f"Device {category} folder not found!")
                continue
            for plugin_archive in os.listdir(plugin_dir):
                print(f"Check Item: {plugin_archive}")
                if plugin_archive.endswith(".zip"):
                    plugin_name = plugin_archive.split(".")[0]
                    plugin_path = os.path.join(plugin_dir, plugin_archive)
                    try:
                        plugin = self.__safely_load_plugin(plugin_path)
                        self.__plugins[category][plugin_name] = plugin
                    except Exception as e:
                        warnings.warn(f"Failed to load plugin {plugin_archive}: {e}")
        if not any(val for key, val in self.__plugins.items()):
            raise RuntimeError("No Plugins found. Please check your plugins directory.")

    @classmethod
    def get_instance(cls):
        """
        Retrieve the singleton instance of the class.
        Raises:
            ReferenceError: If the singleton instance has not been created yet.
            
        :return: The singleton instance of the class.
        """
        if cls not in cls._instances:
            raise ReferenceError("Plugin Manager not initialized yet.")
        return cls._instances[cls]

    @staticmethod
    def __check_plugin(plugin_path:str) -> dict:
        """
        Perform static analysis on plugin structure before dynamic loading.
        Checks for required files and validates the structural correctness of the plugin.        
        
        :param plugin_path: Path to the plugin archive.
        :raises: FileNotFoundError, AttributeError or KeyError for any plugin structure issues.
        :return: Valid manifest.
        """
        with zipfile.ZipFile(plugin_path, 'r') as zip_file:
            manifest_name = 'manifest.json'
            if manifest_name not in zip_file.namelist():
                raise FileNotFoundError("File manifest.json not found in zip file.")
            with zip_file.open(manifest_name) as manifest_file:
                manifest_content = json.load(manifest_file)
            module_filename = f"{manifest_content.get('main_module')}.py"
            class_name = manifest_content.get("main_class")
            if not module_filename or module_filename not in zip_file.namelist():
                raise FileNotFoundError(f"Main Module {module_filename} not found in zip file.")
            if not class_name or not isinstance(class_name, str):
                raise KeyError("Missing or invalid 'main_class' entry in manifest.json.")
            with zip_file.open(module_filename) as main_module:
                contains_main_class = False
                tree = ast.parse(main_module.read())
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef) and node.name == class_name:
                        contains_main_class = True
                        break
                if not contains_main_class:
                    raise AttributeError(f"Main Module File {module_filename} does not contain class {class_name}.")
        return manifest_content

    @staticmethod
    def __validate_and_install_dependencies(dependencies: list[str]):
        """
        Validates and tries to install missing dependencies for a plugin.
        :param dependencies: List of dependencies declared in a plugin's manifest using pip syntax for dependency specification.
        :return List of dependencies if are rightly installed.
        """
        #print(f"Dependencies: {dependencies}")
        res = []
        for dependency in dependencies:
            req = Requirement(dependency)  # Use packaging to analyse dependency - package and version
            package_name = req.name
            version_spec = req.specifier
            #print(f"Package {package_name} with version {version_spec}")
            if import_util.find_spec(package_name):
                installed_version = import_metadata.version(package_name)
                if version_spec and not version_spec.contains(installed_version, prereleases=True):
                    raise ImportWarning(f"Dependency version mismatch: {package_name} is already installed with {installed_version}, but {dependency} requires {version_spec}." )
            else:
                # Package not installed - Try to install
                # TODO - Solve WARNING: pip is being invoked by an old script wrapper.
                pip_main(['install', dependency])  # Install the dependency dynamically
            res.append(req)
        return res

    @staticmethod
    def __import_plugin(plugin_path:str, module_name: str):
        """"""
        try:
            # Any files may be present in the ZIP archive, but importers are only invoked for .py and .pyc files. ZIP import of dynamic modules (.pyd, .so) is disallowed.
            zip_loader = zipimport.zipimporter(plugin_path)
            module_spec = import_util.spec_from_loader(module_name, zip_loader)
            module = import_util.module_from_spec(module_spec)
            module_spec.loader.exec_module(module)
            return module
        # If zip importing does not work:
        #    with zipfile.ZipFile(plugin_path, 'r') as zip_file:
        #        zip_file.extractall(zip_file.filename.split('.')[0])
        #    return importlib.import_module(module_name)
        except Exception as e:
            raise ImportError(f"Error importing module {module_name}: {e}") from e

    @staticmethod
    def __safely_load_plugin(plugin_path):
        """
        Validate and import a plugin into the environment.
        Ensures the presence of manifest, dependencies, main module, and main class before loading.
        """
        try:
            plugin_manifest = PluginManager.__check_plugin(plugin_path)  # Performs validation on the plugin structure.
            dependencies = PluginManager.__validate_and_install_dependencies(plugin_manifest.get("dependencies", []))
            module = PluginManager.__import_plugin(plugin_path, plugin_manifest["main_module"])  # Import the plugin module dynamically
            return Plugin(
                version=plugin_manifest["version"],
                module=module,
                dependencies=dependencies,
                service_class_name=plugin_manifest["main_class"],
                **plugin_manifest.get("init_params", {})
            )  # Return plugin instance - TODO: Generics Checking in runtime?
        except Exception as e:
            raise ImportError(f"Error validating plugin: {e}") from e

    def is_plugin_available(self,  plugin_name: str, device_type: DeviceType):
        """
        Check if the specified camera plugin is already loaded in the runtime environment.
        Args:
            plugin_name (str): The name of the  plugin.
            device_type (DeviceType): The type of the plugin.
        Returns:
            bool: True if the plugin is loaded, False otherwise.
        """
        return plugin_name in self.__plugins[device_type]

    def load_camera_wrapper(self, plugin_name:str) -> Plugin[CameraInterface]:
        if not self.is_plugin_available(plugin_name, DeviceType.CAMERA):
            raise KeyError(f"Camera plugin '{plugin_name}' not imported!")
        plugin = self.__plugins[DeviceType.CAMERA][plugin_name]
        if not plugin.wrapper_is_loaded():
            plugin._load_wrapper()
        return plugin

    def load_stereocamera_wrapper(self, plugin_name:str) -> Plugin[StereoCameraInterface]:
        if not self.is_plugin_available(plugin_name, DeviceType.STEREOCAMERA):
            raise KeyError(f"Camera plugin '{plugin_name}' not imported!")
        plugin = self.__plugins[DeviceType.STEREOCAMERA][plugin_name]
        if not plugin.wrapper_is_loaded():
            plugin._load_wrapper()
        return plugin

    def load_location_system_wrapper(self, plugin_name:str) -> Plugin[LocationSystemInterface]:
        if not self.is_plugin_available(plugin_name, DeviceType.LOCATION_SYSTEM):
            raise KeyError(f"Camera plugin '{plugin_name}' not imported!")
        plugin = self.__plugins[DeviceType.LOCATION_SYSTEM][plugin_name]
        if not plugin.wrapper_is_loaded():
            plugin._load_wrapper()
        return plugin

    def install_new_plugin(self, plugin_name: str, device_type: DeviceType):
        """
        Install a new plugin from a ZIP archive into the system.
        This method allows adding and loading a plugin dynamically during runtime by
        specifying its name and type. The plugin is expected to be structured and
        located inside the correct directory for its type.
        Args:
            plugin_name (str): The name of the plugin (without the .zip extension).
            device_type (DeviceType): The type of the plugin (e.g., CAMERA, STEREOCAMERA, LOCATION_SYSTEM).
        Raises:
            FileNotFoundError: If the plugin archive is not found in the expected type directory.
            ImportError: If the plugin fails to be loaded due to invalid structure or missing dependencies.
        Returns:
            None
        """
        plugin_path = os.path.join(self.__plugins_root, device_type, f"{plugin_name}.zip") # Il file deve essere già scaricato nella cartella coretta. Si suppone lo faccia l'invoker del metodo (e.g. handler del websocket)
        if not os.path.exists(plugin_path):
            raise FileNotFoundError(f"Plugin {plugin_name}.zip not found in {device_type} directory.")
        plugin = self.__safely_load_plugin(plugin_path)
        self.__plugins[device_type][plugin_name] = plugin

    def get_plugin_list(self):
        """
        Retrieve a dictionary representation of the currently loaded plugins.
        """
        plugin_dict = {}
        
        for device_type, plugins in self.__plugins.items():
            plugin_dict[device_type] = {}
            for plugin_name, plugin in plugins.items():
                plugin_dict[device_type][plugin_name] = {
                    'version': plugin.version,
                    'dependencies': [str(dep) for dep in plugin.dependencies],
                    'service_config': plugin.service_config
                }
        
        return plugin_dict

    # TODO: Add other Plug-in manager functions to enable, disable and update plug-ins
