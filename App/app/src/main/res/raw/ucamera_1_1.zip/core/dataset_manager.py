from concurrent.futures.thread import ThreadPoolExecutor
from datetime import datetime
from typing import Optional, Callable, Any
from devices import CameraInterface, StereoCameraInterface, LocationSystemInterface
from storage import GenericData, DeviceInfo, RecordingInfo
from storage.storage_manager import StorageManagerInterface
from utils.constants import DatasetType
from utils import helper

import logging
logging.basicConfig(level=logging.ERROR)

class DatasetManager:

    def __init__(self, max_workers: int = 4):
        self.__handlers = ThreadPoolExecutor(max_workers=max_workers)
        self.__storage_manager: Optional[StorageManagerInterface] = None # Could be a list if we can set more storage but use only one - No composite
        self.__camera: Optional[CameraInterface] = None
        self.__stereocamera: Optional[StereoCameraInterface] = None
        self.__location_system: Optional[LocationSystemInterface] = None

        self.__observers = set()
        # TODO: Check if we can collect at same time two different dataset
        self.__current_dataset: int = -1
        self.__start_recording_time: Optional[datetime] = None

    @property
    def _camera(self) -> CameraInterface:
        return self.__camera

    @_camera.setter
    def _camera(self, camera: CameraInterface):
        self.__camera = camera #Could be changed dynamically at runtime if needed

    @property
    def _stereocamera(self) -> StereoCameraInterface:
        return self.__stereocamera

    @_stereocamera.setter
    def _stereocamera(self, stereocamera: StereoCameraInterface):
        self.__stereocamera = stereocamera #Could be changed dynamically at runtime if needed

    @property
    def _location_system(self) -> LocationSystemInterface:
        return self.__location_system

    @_location_system.setter
    def _location_system(self, location_system: LocationSystemInterface):
        self.__location_system = location_system #Could be changed dynamically at runtime if needed

    @property
    def _storage_manager(self):
        return self.__storage_manager

    @_storage_manager.setter
    def _storage_manager(self, storage_manager: StorageManagerInterface):
        self.__storage_manager = storage_manager  # Could be changed dynamically at runtime if needed

    @property
    def acquisition_running(self):
        #TODO: Check type if we can collect at same time two different dataset
        return self.__current_dataset != -1

    #region status observer
    def _status(self):
        status = dict()
        #TODO: Check type other current_dataset id if we can collect at same time two different dataset
        if self.__current_dataset != -1 and self.__storage_manager is not None:
            try:
                dataset = self.__storage_manager.get_dataset_snapshot(self.__current_dataset)
                status[f"{dataset.type}_acquisition"] = {
                    "dataset_id": self.__current_dataset,
                    "name": dataset.name,
                    "created_at": datetime.fromisoformat(dataset.created_at).timestamp(),
                    "is_completed": dataset.completed,
                    "items": dataset.items,
                    "recording_interval": dataset.recoding_info.recording_interval,
                    "recording_duration": dataset.recoding_info.recording_duration,
                    "device_status": {
                        "name": self.__camera.name if dataset.type==DatasetType.PHOTO else self.__stereocamera.name,
                        "settings": self.__camera.get_settings() if dataset.type==DatasetType.PHOTO else self.__stereocamera.get_settings(),
                        "is_running": self.__camera.is_running if dataset.type==DatasetType.PHOTO else self.__stereocamera.is_running,
                        "is_recording": self.__camera.is_recording if dataset.type==DatasetType.PHOTO else self.__stereocamera.is_recording,
                    }
                }
            except Exception as e:
                logging.error(f"Error retrieving dataset snapshot: {e}", exc_info=True)
        return status

    def register_status_observer(self, observer: Callable[[dict[str, Any]], None]):
        self.__observers.add(observer)

    def unregister_status_observer(self, observer: Callable[[dict[str, Any]], None]):
        self.__observers.discard(observer)

    def notify_status(self):
        safe_obs_copy = list(self.__observers)
        for observer in safe_obs_copy:
            observer(self._status())
    #endregion

    def start_new_acquisition(self, name: str, description: str, interval: float):
        """
        Notify to cameras the start of new photogrammetric dataset and set a callable on shooting in order to save data
        according to storage manager
        """
        if self.__camera is None:
            raise ValueError("Camera is not set. Please set a camera before starting recording.")
        #if interval <= 0:
        #    raise ValueError("Interval must be greater than zero.")
        if self.__current_dataset != -1:
            raise Exception(
                f"An acquisition is already running on dataset with id {self.__current_dataset}. "
                "Stop the current acquisition before starting a new one")
        try:
            self.__current_dataset = self.__storage_manager.create_dataset(
                dataset_name=name,
                dataset_type=DatasetType.PHOTO,
                device=DeviceInfo(name=self.__camera.name, settings=self.__camera.get_settings()),
                rec_interval=interval,
                description=description)
            self.__start_recording_time = datetime.now()
            self.__camera.start_recording(interval, self.save_photo)
            self.notify_status()
            return self.__current_dataset
        except Exception as e:
            self.__start_recording_time = None
            self.__current_dataset = -1 # Reset eventually dataset_id if we create dataset but fails the starting of the recording
            raise RuntimeError(f"Error starting new acquisition: {e}") from e

    def stop_current_acquisition(self):
        """Notify the camera to stop the current dataset acquisition."""
        self.__camera.stop_recording()
        if self.__current_dataset != -1:
            duration = (datetime.now() - self.__start_recording_time).total_seconds()
            self.__storage_manager.close_dataset_acquisition(self.__current_dataset, duration)
            self.__start_recording_time = None
            self.__current_dataset = -1
            self.notify_status()
        else:
            raise RuntimeWarning("There is no active acquisition to stop!")

    def save_photo(self, name: str, photo_data: bytes, photo_ext: str):
        # Use ThreadPoolExecutor to save received camera image on storage
        assert self.__current_dataset != -1, "Dataset Acquisition not started!"
        location_metadata = {}
        issues = []
        latitude = longitude = altitude = None
        try:
            #TODO: Save camera lights and flash settings as Exif if they could be changed during an acquisition
            timestamp, latitude, longitude, altitude =  self.__location_system.get_location() # Get Location from LocationSystem
            dt = datetime.fromtimestamp(timestamp)
            location_metadata["GPSDateStamp"] = f"{dt.year:04d}:{dt.month:02d}:{dt.day:02d}"
            location_metadata["GPSTimeStamp"] = ((dt.hour, 1), (dt.minute, 1), (dt.second, 1))
            lat_grades, lat_minutes, lat_seconds = helper.dd2dms(latitude[0])
            location_metadata["GPSLatitude"] = ((lat_grades, 1), (lat_minutes, 1), helper.float2rational(lat_seconds))
            location_metadata["GPSLatitudeRef"] = latitude[1]
            lon_grades, lon_minutes, lon_seconds = helper.dd2dms(longitude[0])
            location_metadata["GPSLongitude"] = ((lon_grades, 1), (lon_minutes, 1), helper.float2rational(lon_seconds))
            location_metadata["GPSLongitudeRef"] = longitude[1]
            location_metadata["GPSAltitude"] = helper.float2rational(altitude[0])
            location_metadata["GPSAltitudeRef"] = altitude[1]
            if datetime.now().timestamp() - timestamp > 10: # > 10 seconds
                issues.append(f"Data {name} associated with outdated location")
        except Exception as e:
            location_metadata.clear()
            issues.append(f"Error associating location with data {name}: {e}")
            print(f"Error associating location with data {name}: {e}")

        if len(location_metadata)>0:
            # Check for out-of-range values - latitude, lognitude e altitude could not be set but in that case location_metadata was cleared.
            out_of_range = self.check_location_metadata_range(name, location_metadata, latitude, longitude, altitude)

            # If there's an out-of-range value, add an issue to the current dataset
            if out_of_range:
                location_metadata.clear()
                issues.append(f"Location metadata out of range: "
                            f"Image: {name}, Latitude: {latitude}, Longitude: {longitude}, Altitude: {altitude}]")

        try:
            data = GenericData(name, photo_ext, photo_data, metadata=location_metadata)
            future = self.__handlers.submit(self.__storage_manager.save_data,
                                            self.__current_dataset, data)
            future.result()
            duration = (datetime.now() - self.__start_recording_time).total_seconds()
            self.__storage_manager.update_duration(self.__current_dataset, duration)
            self.notify_status()
        except IOError as io_e:
            issues.append(f"Error saving the image: {str(io_e)} "
                          f"Image: {name}, Latitude: {latitude}, Longitude: {longitude}, Altitude: {altitude}]")
        except Exception as e:
            logging.error(f"Error in the thread executing 'storage_manager.save_data': {e}", exc_info=True)
        finally:
            if issues:
                self.__storage_manager.add_issue_messages(self.__current_dataset, *issues)

    def get_datasets(self):
        return self.__storage_manager.current_available_datasets().values()

    def get_dataset_archive_path(self, dataset_id: int) -> str:
        """
        Returns the archive path of the dataset if it's different from the current dataset.
        """
        if dataset_id == self.__current_dataset:
            raise ValueError(f"The current acquisition is running on the requested dataset [id={dataset_id}] and cannot be downloaded.")
        return self.__storage_manager.get_dataset_archive_path(dataset_id)

    def get_dataset(self, dataset_id):
        return self.__storage_manager.get_dataset_snapshot(dataset_id)


    def check_location_metadata_range(self, name, location_metadata, latitude, longitude, altitude):
        """
        Checks if the location metadata values exceed the maximum allowable range.
        
        This validation is necessary because PyExif encounters issues if numerator or denominator 
        exceed 4294967295, leading to failure in writing metadata.
        
        Args:
            name (str): Name of the image file.
            location_metadata (dict): Dictionary containing location metadata.
            latitude (float, str): Latitude value.
            longitude (float, str): Longitude value.
            altitude (float, str): Altitude value.
        
        Returns:
            bool: True if any metadata value is out of range, False otherwise.
        """

        max_value = 4294967295
        out_of_range = False

        for key, value in location_metadata.items():
            if isinstance(value, tuple) and all(isinstance(v, tuple) for v in value):  
                # Only if it's a tuple of tuples (e.g. ((24,1), (29,1), (29950989,879421)))
                for num, den in value:
                    if num > max_value or den > max_value:
                        out_of_range = True
                        print(f"ERROR: Out of range value in {key}: {value} | "
                              f"Original Data -> Latitude: {latitude}, Longitude: {longitude}, Altitude: {altitude} | "
                              f"Dataset Info -> ID: {self.__current_dataset}, Image: {name}")

            elif isinstance(value, tuple) and len(value) == 2:
                # If it's a single tuple (e.g. GPSAltitude: (5894158918, 817267))
                num, den = value
                if num > max_value or den > max_value:
                    out_of_range = True
                    print(f"ERROR: Out of range value in {key}: {value} | "
                          f"Original Data -> Latitude: {latitude}, Longitude: {longitude}, Altitude: {altitude} | "
                          f"Dataset Info -> ID: {self.__current_dataset}, Image: {name}")
                          
        return out_of_range