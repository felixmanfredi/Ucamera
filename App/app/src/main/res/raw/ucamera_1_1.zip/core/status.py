from abc import ABCMeta, abstractmethod
from enum import StrEnum
from typing import Optional
from utils.constants import DatasetType


class Status(metaclass=ABCMeta):

    """
    Common interface to represent a Status. Not used directly by wrappers and devices that notify the status as
    key-value pairs. This hierarchy only aims to abstract information we want to track and provide externally,
    compared to those made available by the devices, as events (status_id, status_data).
    """

    def __init__(self, status_id:str):
        self._id = status_id

    @property
    def status_id(self):
        return self._id

    @classmethod
    def _hidden_fields(cls) -> set[str]:
        return {"_id"}

    @abstractmethod
    def update(self, **status_data):
        raise NotImplementedError("Update function not implemented!")

    def as_dict(self):
        """Returns the data as a dictionary, automatically excluding specific fields."""
        exclude_fields = self._hidden_fields()  # Set of fields to exclude
        return {
            key.lstrip("_"): value  # Removes the '__' prefix from private names
            for key, value in self.__dict__.items()
            if key not in exclude_fields and value is not None
        }


class BoardStatus(Status):

    def __init__(self, cpu_temp: Optional[float] = None, cpu_usage: Optional[float] = None, free_ram: Optional[int] = None,
                 used_ram: Optional[int] = None, free_disk: Optional[int] = None, used_disk: Optional[int] = None):
        super().__init__("board_status")
        self._cpu_temp = cpu_temp
        self._cpu_usage = cpu_usage
        self._free_ram = free_ram
        self._used_ram = used_ram
        self._free_disk = free_disk
        self._used_disk = used_disk

    @property
    def cpu_temp(self):
        return self._cpu_temp

    @property
    def cpu_usage(self):
        return self._cpu_usage

    @property
    def free_ram(self):
        return self._free_ram

    @property
    def used_ram(self):
        return self._used_ram

    @property
    def free_disk(self):
        return self._free_disk

    @property
    def used_disk(self):
        return self._used_disk

    def update(self, **status_data):
        if cpu_temp := status_data.get("cpu_temp"):
            self._cpu_temp = cpu_temp
        if cpu_usage := status_data.get("cpu_usage"):
            self._cpu_usage = cpu_usage
        if free_ram := status_data.get("free_ram"):
            self._free_ram = free_ram
        if used_ram := status_data.get("used_ram"):
            self._used_ram = used_ram
        if free_disk := status_data.get("free_disk"):
            self._free_disk = free_disk
        if used_disk := status_data.get("used_disk"):
            self._used_disk = used_disk


class LocationStatus(Status):

    def __init__(self, is_running: bool=False, timestamp: Optional[float] = None, latitude: Optional[tuple[float,str]] = None,
                 longitude: Optional[tuple[float,str]] = None, altitude: Optional[tuple[float,str]] = None):
        super().__init__("location_status")
        self._is_running = is_running
        self._timestamp = timestamp
        self._latitude = latitude
        self._longitude = longitude
        self._altitude = altitude
        self._timestamp = timestamp

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def latitude(self) -> tuple[float,str]:
        return self._latitude

    @property
    def longitude(self) -> tuple[float,str]:
        return self._longitude

    @property
    def altitude(self) -> tuple[float,str]:
        return self._altitude

    @property
    def timestamp(self) -> float:
        return self._timestamp

    def update(self, **status_data):
        if "is_running" in status_data:
            # False is an interesting value
            self._is_running = status_data.get("is_running")
        if timestamp := status_data.get("timestamp"):
            self._timestamp = timestamp
        if latitude := status_data.get("latitude"):
            self._latitude = latitude
        if longitude := status_data.get("longitude"):
            self._longitude = longitude
        if altitude := status_data.get("altitude"):
            self._altitude = altitude


class DeviceStatus(Status):

    def __init__(self, name:str, settings: dict[str, any], is_running: Optional[bool] = None, is_recording: Optional[bool] = None, data=None):
        super().__init__("device_status") #TODO: Handle type of camera
        self._name = name
        self._is_running = is_running
        self._settings = settings
        self._is_recording = is_recording
        self._data=data

    @property
    def name(self):
        return self._name

    @property
    def is_running(self):
        return self._is_running

    @property
    def settings(self):
        return self._settings

    @property
    def is_recording(self):
        return self._is_recording

    @property
    def data(self):
        return self._data


    def update(self, **status_data):
        if name := status_data.get("name"):
            self._name = name
        if "is_running" in status_data:
            # False is an interesting value
            self._is_running = status_data.get("is_running")
        if settings := status_data.get("settings"):
            self._settings = settings
        if "is_recording" in status_data:
            # False is an interesting value
            self._is_recording = status_data.get("is_recording")
        if "data" in status_data:
            # False is an interesting value
            self.data = status_data.get("data")


class AcquisitionStatus(Status):

    def __init__(self, dataset_id: int, name: str, dtype: DatasetType, is_completed: bool = False, created_at: Optional[float] = None,
                 items_size: Optional[int] = None, device_status: Optional[DeviceStatus] = None,
                 recording_interval: Optional[float] = None, recording_duration: Optional[float] = None):
        super().__init__(f"{dtype}_acquisition_status")
        self._dataset_id = dataset_id
        self._name = name
        self._created_at = created_at
        self._is_completed = is_completed
        self._items = items_size
        self._device_status = device_status
        self._recording_interval = recording_interval
        self._recording_duration = recording_duration

    @classmethod
    def zero_acquisition(cls, dtype: DatasetType) -> "AcquisitionStatus":
        return cls(-1, "No Acquisition", dtype)

    @property
    def dataset_id(self):
        return self._dataset_id

    @property
    def name(self):
        return self._name

    @property
    def created_at(self):
        return self._created_at

    @property
    def is_completed(self):
        return self._is_completed

    @property
    def items(self):
        return self._items

    @property
    def recording_info(self):
        if self._device_status and self._device_status.is_recording:
            status = dict()
            status["recording_interval"] = self._recording_interval
            status["recording_duration"] = self._recording_duration
            return status
        return None

    @property
    def device_status(self):
        return self._device_status

    def update(self, **status_data):
        print(status_data)
        if (id:= status_data.get("dataset_id")) >= 0:
            self._dataset_id = id
        if name := status_data.get("name"):
            self._name = name
        if created_at := status_data.get("created_at"):
            self._created_at = created_at
        if "is_completed" in status_data:
            # False is an interesting value
            self._is_completed = status_data.get("is_completed")
        if (items := status_data.get("items")) >= 0:
            self._items = items
        if device_status := status_data.get("device_status"):
            """
            This object is included in DatasetStatus and not directly notified to websocket clients. It is updated only 
            if an acquisition already exists, so device_status cannot be None. 
            Once an acquisition is stopped, only DatasetStatus is reset. 
            """
            if not self._device_status:
                self._device_status = DeviceStatus(**device_status)
            else:
                self._device_status.update(**device_status)
        self._recording_interval = status_data.get("recording_interval")  # If not preset we set to None [is_recording = false]
        self._recording_duration = status_data.get("recording_duration")  # If not preset we set to None [is_recording = false]

    def as_dict(self):
        """Returns the data as a dictionary, automatically excluding specific fields."""
        res = dict()
        if self._name == "No Acquisition":
            return res
        exclude_fields = self._hidden_fields()  # Set of fields to exclude
        for key, value in self.__dict__.items():
            if key not in exclude_fields and value is not None:
                try:
                    if isinstance(value, Status):
                        res[key.lstrip("_")] = value.as_dict()
                    else:
                        res[key.lstrip("_")] = value
                except Exception as e:
                    print(str(e))
        return res

class DatasetsStorageStatus(Status):

    """
    Information on current acquisitions and the space occupied by datasets on the storage device compared to free space.

    We differentiate between occupied and available disk space and storage device space for datasets.
    """

    def __init__(self, free_storage_space: Optional[int] = None, used_storage_space: Optional[int] = None,
                 photo_acquisition: Optional[AcquisitionStatus] = None,
                 point_cloud_acquisition: Optional[AcquisitionStatus] = None):
        super().__init__("datasets_storage_status")
        self._free_dataset_space = free_storage_space
        self._used_dataset_space = used_storage_space
        self._current_photo_acquisition = photo_acquisition if photo_acquisition else AcquisitionStatus.zero_acquisition(DatasetType.PHOTO)
        self._current_point_cloud_acquisition = point_cloud_acquisition if point_cloud_acquisition else AcquisitionStatus.zero_acquisition(DatasetType.POINT_CLOUD)


    @property
    def free_dataset_space(self):
        return self._free_dataset_space

    @property
    def used_dataset_space(self):
        return self._used_dataset_space

    @property
    def photo_acquisition(self):
        return self._current_photo_acquisition

    @property
    def point_cloud_acquisition(self):
        return self._current_point_cloud_acquisition

    def reset_photo_acquisition(self):
        self._current_photo_acquisition = AcquisitionStatus.zero_acquisition(DatasetType.PHOTO)

    def reset_point_cloud_acquisition(self):
        self._current_point_cloud_acquisition = AcquisitionStatus.zero_acquisition(DatasetType.POINT_CLOUD)

    def update(self, **status_data):
        if free_dataset_space := status_data.get("free_dataset_space"):
            self._free_dataset_space = free_dataset_space
        if used_dataset_space := status_data.get("used_dataset_space"):
            self._used_dataset_space = used_dataset_space
        if photo_acquisition := status_data.get("photo_acquisition"):
            self._current_photo_acquisition.update(**photo_acquisition)
        if point_cloud_acquisition := status_data.get("point_cloud_acquisition"):
            self._current_point_cloud_acquisition.update(**point_cloud_acquisition)

    def as_dict(self):
        """Returns the data as a dictionary, automatically excluding specific fields."""
        res = dict()
        exclude_fields = self._hidden_fields()  # Set of fields to exclude
        for key, value in self.__dict__.items():
            if key not in exclude_fields and value is not None:
                if isinstance(value, Status):
                    res[key.lstrip("_")] = value.as_dict()
                else:
                    res[key.lstrip("_")] = value
        return res


class SystemStatus(Status):

    class Component(StrEnum):
        CAMERA = "camera"
        STEREOCAMERA = "stereocamera"
        LOCATION = "location"
        DATASET = "dataset"
        BOARD = "board"


    def __init__(self):
        super().__init__("system_status")
        self._components: dict[str, any] = {
            self.Component.BOARD: BoardStatus(),
            self.Component.LOCATION: LocationStatus(),
            self.Component.DATASET: DatasetsStorageStatus(),
            self.Component.CAMERA: None,
            self.Component.STEREOCAMERA: None,
        }

    @property
    def camera_status(self) -> DeviceStatus:
        return self._components[self.Component.CAMERA]

    @camera_status.setter
    def camera_status(self, value: Optional[DeviceStatus]):
        self._components[self.Component.CAMERA] = value

    @property
    def stereocamera_status(self) -> DeviceStatus:
        return self._components[self.Component.STEREOCAMERA]

    @stereocamera_status.setter
    def stereocamera_status(self, value: Optional[DeviceStatus]):
        self._components[self.Component.STEREOCAMERA] = value

    @property
    def location_status(self) -> LocationStatus:
        return self._components[self.Component.LOCATION]

    @property
    def dataset_status(self) -> DatasetsStorageStatus:
        return self._components[self.Component.DATASET]

    @property
    def board_status(self) -> BoardStatus:
        return self._components[self.Component.BOARD]

    def update(self, **status_data):
        for component_id, component_status in status_data.items():
            if component := self._components.get(component_id):
                # In this case we do not accept None value for subcomponent to force controller to call setter
                component.update(**component_status)

    def as_dict(self):
        """Returns the data as a dictionary, automatically excluding specific fields."""
        res = dict()
        exclude_fields = self._hidden_fields()  # Set of fields to exclude
        for key, value in self.__dict__.items():
            if key not in exclude_fields and value is not None:
                if isinstance(value, Status):
                    res[key.lstrip("_")]: value.as_dict()
                else:
                    res[key.lstrip("_")] = value
        return res