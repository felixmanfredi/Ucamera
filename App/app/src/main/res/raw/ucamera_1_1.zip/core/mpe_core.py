import threading
import warnings
from threading import Event
from typing import Optional, Callable
from core.dataset_manager import DatasetManager
from core.plugin import PluginManager
from core.status import Status, SystemStatus, DeviceStatus, DatasetsStorageStatus
from devices import CameraInterface, StereoCameraInterface, LocationSystemInterface
from devices import create_location_system, create_stereocamera, create_camera
from storage import StorageManagerInterface, create_storage
from utils.constants import DeviceType
from utils.mpe_typing import Singleton

def monitor_board(stop_event: Event, callback: Callable[[dict[str, any]], None]):
    import psutil
    import time
    time.sleep(3)
    status_data = dict()
    while not stop_event.is_set():
        status_data.clear()
        status_data["cpu_usage"] = psutil.cpu_percent(interval=0)
        if hasattr(psutil, "sensors_temperatures"):
            hw_temps = psutil.sensors_temperatures()
            if "cpu_thermal" in hw_temps:
                status_data["cpu_temp"] = hw_temps["cpu_thermal"][0].current
            elif "coretemp" in hw_temps:
                status_data["cpu_temp"] = hw_temps["coretemp"][0].current
        ram = psutil.virtual_memory()
        status_data["free_ram"] = ram.free
        status_data["used_ram"] = ram.used
        status_data["free_disk"] = dict()
        status_data["used_disk"] = dict()
        for disk in psutil.disk_partitions():
            status_data["free_disk"][disk.mountpoint] = psutil.disk_usage(disk.mountpoint).free
            status_data["used_disk"][disk.mountpoint] = psutil.disk_usage(disk.mountpoint).used
        callback(status_data)
        time.sleep(3)
    print("Board Monitor Stopped.")

class MPECore(metaclass=Singleton):
    """
    Facade that defines a simple interface for accessing functionalities:
    - Wrapped Service (Camera, StereoCamera, and Localization System) Management;
    - System Status Access;
    - Dataset Management;
    - Storage Access.

    The services managed by MPECore are started and stopped by the launcher after the initialisation phase via the
     start and stop methods.

    They can also be replaced at runtime via the plugin management methods. These methods can  stop the execution
     of the current service and possibly replace it with another service. The methods of plugin management methods
     take care of checking the state of the system and keeping it consistent with the execution.

    The service setters therefore only take care of setting the service interfaces during initialisation and at
     runtime without checking the state of the system.
    """

    _stop_event = Event()

    def __init__(self):
        self.__camera: Optional[CameraInterface] = None
        self.__stereocamera: Optional[StereoCameraInterface] = None
        self.__location_system: Optional[LocationSystemInterface]  = None
        self.__storage_manager: Optional[StorageManagerInterface] = None

        self.__observers: set[Callable[[str, dict], None]] = set() # event_id, event_data
        self.__status: SystemStatus = SystemStatus()
        self.__dataset_manager = DatasetManager()  # Let's see as a Mediator that handle only dataset operations (generation, exportation, ...)
        self.__dataset_manager.register_status_observer(self.handle_acquisition_status)
        self.__plugin_manager: PluginManager = PluginManager.get_instance()


    @classmethod
    def get_instance(cls):
        """
        Retrieve the singleton instance of the class.
        Raises:
            ReferenceError: If the singleton instance has not been created yet.
            
        :return: The singleton instance of the class.
        """
        if cls not in cls._instances:
            raise ReferenceError("Plugin Manager not initialized yet.")
        return cls._instances[cls]

    @property
    def _status(self):
        return self.__status

    @property
    def _camera(self) -> CameraInterface:
        return self.__camera

    @_camera.setter
    def _camera(self, camera: Optional[CameraInterface]):
        if camera is not None:
            # update status observer to update automatically callback to every camera changes
            self.__status.camera_status = DeviceStatus(camera.name, camera.get_settings())  # Existing status is overridden
            camera.register_status_observer(self.handle_camera_status)
        else:
            self.__status.camera_status = None
        self.__camera = camera
        self.__dataset_manager._camera = camera

    @property
    def _stereocamera(self) -> StereoCameraInterface:
        return self.__stereocamera

    @_stereocamera.setter
    def _stereocamera(self, stereocamera: Optional[StereoCameraInterface]):
        if stereocamera is not None:
            # update status observer to update automatically callback to every stereocamera changes
            self.__status.stereocamera_status = DeviceStatus(stereocamera.name, stereocamera.get_settings())  # Existing status is overridden
            stereocamera.register_status_observer(self.handle_stereocamera_status)
        else:
            self.__status.stereocamera_status = None
        self.__stereocamera = stereocamera
        self.__dataset_manager._stereocamera = stereocamera

    @property
    def _location_system(self) -> LocationSystemInterface:
        return self.__location_system

    @_location_system.setter
    def _location_system(self, location_system: LocationSystemInterface):
        self.__location_system = location_system
        self.__dataset_manager._location_system = location_system
        # update status observer to update automatically callback to every location system changes
        self.__location_system.register_status_observer(self.handle_location_status)

    @property
    def _storage_manager(self):
        return  self.__storage_manager

    @_storage_manager.setter
    def _storage_manager(self, storage_manager: StorageManagerInterface):
        if storage_manager is None:  # Constructor does not call this method
            raise ValueError("Storage manager cannot be None. Please provide a valid storage manager.")
        self.__storage_manager = storage_manager
        self.__dataset_manager._storage_manager = storage_manager

    # region Status Management

    def register_status_observer(self, observer: Callable[[str, dict], None]):
        self.__observers.add(observer)  # No effect if the element is already present.

    def unregister_status_observer(self, observer: Callable[[str, dict], None]):
        """
        Un register callback function to avoid memory leak.
        """
        self.__observers.discard(observer) # No effect if the element is missing.

    def notify_system_status(self, status: Status):
        safe_obs_copy = list(self.__observers)
        for observer in safe_obs_copy:
            observer(status.status_id, status.as_dict())

    def handle_camera_status(self, status_data: dict[str, any]):
        subcomponent_status = {
            SystemStatus.Component.CAMERA: status_data
        }
        self.__status.update(**subcomponent_status)
        self.notify_system_status(self.__status.camera_status)

    def handle_stereocamera_status(self, status_data: dict[str, any]):
        subcomponent_status = {
            SystemStatus.Component.STEREOCAMERA: status_data
        }
        self.__status.update(**subcomponent_status)
        self.notify_system_status(self.__status.stereocamera_status)

    def handle_location_status(self, status_data: dict[str, any]):
        subcomponent_status = {
            SystemStatus.Component.LOCATION: status_data
        }
        self.__status.update(**subcomponent_status)
        self.notify_system_status(self.__status.location_status)

    def handle_acquisition_status(self, status_data: dict[str, any]):
        # We send another message since we can change camera instance/setting continuing to show the result status of
        # previous acquisition.
        status_data[DatasetsStorageStatus.free_dataset_space.fget.__name__] = self.__storage_manager.get_free_storage_space()
        status_data[DatasetsStorageStatus.used_dataset_space.fget.__name__] = self.__storage_manager.get_used_storage_space()
        subcomponent_status = {
            SystemStatus.Component.DATASET: status_data
        }
        self.__status.update(**subcomponent_status)
        self.notify_system_status(self.__status.dataset_status)

    def handle_board_status(self, status_data: dict[str, any]):
        subcomponent_status = {
            SystemStatus.Component.BOARD: status_data
        }
        self.__status.update(**subcomponent_status)
        self.notify_system_status(self.__status.board_status)

    # endregion

    # TODO: Add Facade Methods to set camera/stereocamera settings, to handle localization and storage systems

    ### Dataset Methods
    def get_datasets(self):
        datasets = self.__dataset_manager.get_datasets()
        return [dataset.as_dict() for dataset in datasets]

    def get_dataset(self, dataset_id):
        return self.__dataset_manager.get_dataset_archive_path(int(dataset_id))

    def start_new_acquisition(self, dataset_name, description, interval):
        return self.__dataset_manager.start_new_acquisition(dataset_name, description, interval)

    def stop_current_acquisition(self):
        self.__dataset_manager.stop_current_acquisition()
        self.__status.dataset_status.reset_photo_acquisition()

    def get_dataset_info(self, dataset_id):
        return self.__dataset_manager.get_dataset(int(dataset_id)).as_dict()

    # Camera Methods
    def get_camera_settings(self):
        if self.__camera:
            return self.__camera.get_settings()
        return None

    def set_camera_settings(self, settings):
        if self.__camera:
            self.__camera.set_settings(settings)

    def capture_camera(self):
        if self.__camera:
            event = threading.Event()
            image = None
            ext = None

            def capture_callback(name: str, image_data: bytes, extension: str):
                print(f"Image Captured: {name}.{extension}")
                nonlocal image, ext
                image = image_data
                ext = extension
                event.set()

            self.__camera.capture_image(capture_callback)
            event.wait()
            return image, ext
        return None, None

    def preview_camera(self):
        if self.__camera:
            event = threading.Event()
            image = None
            ext = None

            def preview_callback(image_data: bytes, extension: str):
                nonlocal image, ext
                image = image_data
                ext = extension
                event.set()

            self.__camera.preview_image(preview_callback)
            event.wait()
            return image, ext
        return None, None

    def get_camera_lights(self):
        if self.__camera:
            lights = self.__camera.get_lights()
            if isinstance(lights, int):
                lights = {"intensity": lights}
            return lights
        return None
    
    def set_camera_lights(self, **lights_params):
        if self.__camera:
            return self.__camera.set_lights(**lights_params)
        return None
    
    def get_camera_flash(self):
        if self.__camera:
            flash = self.__camera.get_flash()
            if isinstance(flash, int):
                flash = {"intensity": flash}
            return flash
        return None
    
    def set_camera_flash(self, **flash_params):
        if self.__camera:
            return self.__camera.set_flash(**flash_params)
        return None

    # Sterocamera Methods
    # TODO

    # Plugins Methods
    # TODO Add other plugins methods
    def get_plugins(self):
        return self.__plugin_manager.get_plugin_list()

    def enable_plugin(self, plugin_name:str, plugin_type: DeviceType, **init_params):
        """
        Abilita un plugin sostituendo il precedente se presente e riavviando i servizi
        """
        if self.__dataset_manager.acquisition_running:  # TODO: Check acquisition type if we can collect at same time two different dataset
            raise ValueError("Cannot change service during acquisition. Please stop acquisition first.")
        # TODO: Check if plugin_name is already enabling and running using PluginManager
        if plugin_type == DeviceType.LOCATION_SYSTEM:
            location_system = create_location_system(plugin_name, **init_params) # raise an error if loading fails
            if self._location_system is not None:
                self._location_system.unregister_status_observer(self.handle_location_status) # unregister observer to avoid memory leak
                self._location_system.stop_service()
            self._location_system = location_system
            self._location_system.start_service()
        elif plugin_type == DeviceType.CAMERA:
            camera = create_camera(plugin_name, **init_params) # raise an error if loading fails
            if self._camera is not None:
                self._camera.unregister_status_observer(self.handle_camera_status) # unregister observer to avoid memory leak
                self._camera.stop_service()
            self._camera = camera
            self._camera.start_service()
        elif plugin_type == DeviceType.LOCATION_SYSTEM:
            stereocamera = create_stereocamera(plugin_name, **init_params) # raise an error if loading fails
            if self._stereocamera is not None:
                self._stereocamera.unregister_status_observer(self.handle_stereocamera_status)  # unregister observer to avoid memory leak
                self._stereocamera.stop_service()
            self._stereocamera = stereocamera
            self._stereocamera.start_service()
        else:
            raise ValueError(f"Unknown Service Type: {plugin_type}. Please provide a valid type.")


    def disable_plugin(self, plugin_name:str, plugin_type: DeviceType):
        """
        Disabilita un plugin eliminando il precedente se presente e riavviando i servizi
        """
        if self.__dataset_manager.acquisition_running:  # TODO: Check acquisition type if we can collect at same time two different dataset
            raise ValueError("Cannot disable service during acquisition. Please stop acquisition first.")
        # TODO: Check if plugin_name is already enabling and running using PluginManager
        if plugin_type == DeviceType.LOCATION_SYSTEM:
            raise ValueError("Location System cannot be disable, but you can change current service enabling another one.")
        elif plugin_type == DeviceType.CAMERA:
            if self._stereocamera is None:
                raise ValueError("Camera and StereoCamera cannot be both unset. Please provide at least one acquisition device.")
            if self._camera is not None:
                self._camera.unregister_status_observer(self.handle_camera_status) # unregister observer to avoid memory leak
                self._camera.stop_service()
            self._camera = None
        elif plugin_type == DeviceType.LOCATION_SYSTEM:
            if self._camera is None:
                raise ValueError("Camera and StereoCamera cannot be both unset. Please provide at least one acquisition device.")
            if self._stereocamera is not None:
                self._stereocamera.unregister_status_observer(self.handle_stereocamera_status)  # unregister observer to avoid memory leak
                self._stereocamera.stop_service()
            self._stereocamera = None
        else:
            raise ValueError(f"Unknown Service Type: {plugin_type}. Please provide a valid type.")

    def install_plugin(self):
        """
        Installa un nuovo plugin e lo aggiunge al plugin-manager
        :return:
        """
        ... # TODO

    def uninstall_plugin(self):
        """
        Disinstalla un nuovo plugin e lo rimuove dal plugin-manager
        :return:
        """
        ... # TODO

    # System Methods
    def start(self):
        flags = []
        if self.__camera:
            started = self.__camera.start_service()
            flags.append(started)
            if not started:
                warnings.warn("Camera service is not started.")
        if self.__stereocamera:
            started = self.__stereocamera.start_service()
            flags.append(started)
            if not started:
                warnings.warn("Stereocamera service is not started.")
        if self.__location_system:
            started = self.__location_system.start_service()
            flags.append(started)
            if not started:
                warnings.warn("Location system service is not started.")
        if len(flags) != 0 and all(flags):
            # All registered services are started.
            self._stop_event.clear()
            thread = threading.Thread(target=monitor_board, args=(self._stop_event, self.handle_board_status,), daemon=True)
            thread.start()
        else:
            raise RuntimeError("Some services could not be started.")

    def stop(self):
        # If the service is killed, I do not force the closure of the dataset so the dataset continues to be incomplete:
        #if self.__dataset_manager.acquisition_running:
        #    self.__dataset_manager.stop_current_acquisition()
        self._stop_event.set()
        if self.__camera and self.__camera.is_running:
            self.__camera.stop_service()
        if self.__stereocamera and self.__stereocamera.is_running:
            self.__stereocamera.stop_service()
        if self.__location_system and self.__location_system.is_running:
            self.__location_system.stop_service()

    def restart(self):
        self.stop()
        self.start()

    def reboot(self):
        raise NotImplementedError("Method 'reboot' not yet implemented (its behavior should be defined)")

    class Builder:

        def __init__(self):
            self.__product = MPECore()

        @property
        def product(self) -> 'MPECore':
            if not self._valid_result():
                raise TypeError("ModularProExtension not well configured!")
            return self.__product

        def _valid_result(self) -> bool:
            has_cameras = any([
                self.__product._camera is not None,
                self.__product._stereocamera is not None
            ]) # Almeno una delle due deve essere presente
            has_localizer = self.__product._location_system is not None # Required a Localizer
            has_storage_manager = self.__product._storage_manager is not None # Required a Storage Manager
            return has_cameras and has_localizer and has_storage_manager

        def build_camera(self, name: str, **init_params):
            try:
                self.__product._camera = create_camera(name, **init_params)
            except Exception as e:
                raise ValueError("Error during Camera Initialization: {}".format(e))

        def build_stereocamera(self, name:str, **init_params):
            try:
                self.__product._stereocamera = create_stereocamera(name, **init_params)
            except Exception as e:
                raise ValueError("Error during Stereocamera Initialization: {}".format(e))

        def build_location_system(self, name:str, **init_params):
            try:
                self.__product._location_system = create_location_system(name, **init_params)
            except Exception as e:
                raise ValueError("Error during Localizer Initialization: {}".format(e))

        def build_storage(self, name:str, **init_params):
            try:
                self.__product._storage_manager = create_storage(name, **init_params)
            except Exception as e:
                raise ValueError("Error during Storage Initialization: {}".format(e))
