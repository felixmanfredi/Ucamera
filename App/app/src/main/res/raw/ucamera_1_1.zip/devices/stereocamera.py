from abc import ABCMeta, abstractmethod
from datetime import datetime
from typing import Any, Optional, Callable


class StereoCameraInterface(metaclass=ABCMeta):

    @abstractmethod
    def __init__(self, name: str):
        self.__name = name
        self._is_running = False
        self._is_recording = False
        self._recording_starting_time: Optional[datetime] = None
        self._recording_interval: Optional[float] = None
        self.__observers = set()

    @property
    def name(self):
        return self.__name

    @property
    def is_running(self):
        return self._is_running

    @property
    def is_recording(self):
        return self._is_recording

    def _status(self, add_settings: bool = False):
        status = {
            "is_running": self._is_running,
            "is_recording": self._is_recording
        }
        if self._is_recording:
            status["recording_duration"] = (datetime.now() - self._recording_starting_time).total_seconds()
            status["recording_interval"] = self._recording_interval
        if add_settings:
            status["settings"] = self.get_settings()
        return status

        # Notify status including name, if recording is_running, duration of running ...

    def register_status_observer(self, observer: Callable[[dict[str, Any]], None]):
        if observer not in self.__observers:
            self.__observers.add(observer)
            observer(self._status(True))  # Provide current status to new observer

    def unregister_status_observer(self, observer: Callable[[dict[str, Any]], None]):
        self.__observers.discard(observer)

    def notify_status(self, add_settings: bool = False):
        safe_obs_copy = list(self.__observers)
        for observer in safe_obs_copy:
            observer(self._status(add_settings))

    # region: register decorators on abstract template method
    @classmethod
    def __update_recoding_field(cls, function):

        def wrapper(self, interval, *args, **kwargs):
            function(self, interval, *args, **kwargs) # We execute other instructions only if function does not raise an error
            self._recording_starting_time = datetime.now()
            self._recording_interval = interval
            self._is_recording = True
            self.notify_status()

        return wrapper

    @classmethod
    def __reset_recoding_field(cls, function):

        def wrapper(self, *args, **kwargs):
            function(self, *args, **kwargs) # We execute other instructions only if function does not raise an error
            self._recording_starting_time = None
            self._recording_interval = None
            self._is_recording = False
            self.notify_status()

        return wrapper

    @classmethod
    def __notify_settings_changes(cls, function):

        def wrapper(self, *args, **kwargs):
            function(self, *args, **kwargs)
            self.notify_status(True)

        return wrapper

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls.start_point_cloud_recording = cls.__update_recoding_field(cls.start_point_cloud_recording)
        cls.stop_point_cloud_recording = cls.__reset_recoding_field(cls.stop_point_cloud_recording)
        cls.set_settings = cls.__notify_settings_changes(cls.set_settings)

    # endregion

    @abstractmethod
    def start_service(self) -> bool:
        """
        Represents an abstract method that initializes and starts a service.

        This method must be implemented by any derived class. It serves
        as a template for enabling specific service operations, enforcing
        that subclasses provide their customized implementation.

        :raises NotImplementedError: If the subclass does not override this method.
        :return: A boolean indicating the success of starting the service.
        :rtype: bool
        """
        raise NotImplementedError("Start function not implemented!")

    @abstractmethod
    def stop_service(self):
        raise NotImplementedError("Stop function not implemented!")

    @abstractmethod
    def get_settings(self):
        raise NotImplementedError("Get Settings function not implemented!")

    @abstractmethod
    def set_settings(self, settings: dict[str, Any]):
        raise NotImplementedError("Set Settings function not implemented!")

    @abstractmethod
    def get_depth_map(self):
        raise NotImplementedError("Get Depth Map function not implemented!")

    @abstractmethod
    def capture_images(self, callback: Callable[[Any, Any], None], with_depth_map: bool = False):
        """
         Capture and notification of right and left image superimposed on depth maps if with_depth_map=True
        """
        raise NotImplementedError("Capture Images with/without depth map function not implemented!")

    @abstractmethod
    def get_distance(self) -> float:
        raise NotImplementedError("Get Distance function not implemented!")

    @abstractmethod
    def start_point_cloud_recording(self, interval: float, callback: Callable[[Any], None]):
        """
        Start recording for point cloud. Dataset Manager set callable similarly to camera recording
        """
        raise NotImplementedError("Start Recording function not implemented!")

    @abstractmethod
    def stop_point_cloud_recording(self):
        pass
