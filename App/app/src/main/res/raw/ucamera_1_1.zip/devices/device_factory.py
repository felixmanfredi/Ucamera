from devices import CameraInterface, StereoCameraInterface, LocationSystemInterface
from core.plugin import PluginManager
from utils.constants import DeviceType

"""
Factory Methods for create wrappers object. It supports the creation both native and plugin components. For
example if we decide in the future to handle more Cameras we could create a Composite Native Object including
several plugin components.
We use kwargs to define additional arguments useful in future to extend the creation of an adapter.

This module exports the creation functions of the main devices to also allow the operational configuration of the 
MPECore to be updated at runtime. These methods for consistency are also invoked by the Builder which builds the 
MPECore during the launching of the service following, of course, certain checks on the data.
"""

def create_camera(name: str, **kwargs)-> CameraInterface:
    plugin_manager = PluginManager.get_instance()
    #print(plugin_manager.get_plugin_list())
    if plugin_manager.is_plugin_available(name, DeviceType.CAMERA):
        return plugin_manager.load_camera_wrapper(name).service
    else:
        raise ValueError(f"Not Supported Camera {name}")


def create_stereocamera(name: str, **kwargs)-> StereoCameraInterface:
    plugin_manager = PluginManager.get_instance()
    if plugin_manager.is_plugin_available(name, DeviceType.STEREOCAMERA):
        return plugin_manager.load_stereocamera_wrapper(name).service
    else:
        raise ValueError(f"Not Supported Stereocamera {name}")


def create_location_system(name: str, **kwargs)-> LocationSystemInterface:
    plugin_manager = PluginManager.get_instance()
    if plugin_manager.is_plugin_available(name, DeviceType.LOCATION_SYSTEM):
        return plugin_manager.load_location_system_wrapper(name).service
    else:
        raise ValueError(f"Not Supported Location System {name}")

