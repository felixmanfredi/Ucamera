import requests
import json

# Configure these values before running the script
API_KEY = "PMAK-67b4b3577302df0001558548-425d57c39c8bb59d6b13aa682fc273f577"
COLLECTION_ID = "7292954-f39db98e-5694-437b-897d-dffa3ccf6dc4"
UPDATED_COLLECTION_FILE = "Webserver API.postman_collection.json"

# Postman API URL to update the collection
POSTMAN_API_URL = f"https://api.getpostman.com/collections/{COLLECTION_ID}"

# Read the updated collection file
with open(UPDATED_COLLECTION_FILE, "r", encoding="utf-8") as f:
    updated_collection = json.load(f)

# Ensure the structure is correct
payload = {"collection": updated_collection}

# Create the PUT request to update the collection
headers = {
    "X-Api-Key": API_KEY,
    "Content-Type": "application/json"
}
response = requests.put(POSTMAN_API_URL, headers=headers, json=payload)

# Print the result
if response.status_code == 200:
    print("✅ Collection successfully updated on Postman!")
else:
    print("❌ Error updating the collection:", response.text)
