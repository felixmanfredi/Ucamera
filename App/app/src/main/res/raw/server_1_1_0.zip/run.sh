source env/bin/activate
python3 cli/launch.py run
