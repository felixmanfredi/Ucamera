# MPE Server

## Description
MPE Server is a server application for managing photogrammetric data, dataset acquisition, and controlling devices such as cameras and localization systems. The project uses Flask to handle REST and WebSocket communications.

## Requirements
- Python 3.8+
- Flask
- Flask-SocketIO
- Other dependencies listed in `requirements.txt`

## Installation
1. Clone the repository:
   ```sh
   git clone <repository_url>
   cd <repository_name>
   ```
2. Create a virtual environment (optional but recommended):
   ```sh
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```sh
   pip install -r requirements.txt
   ```

## Running the Application

To start the application with mock camera and location system, run:

```sh
python cli/launch.py run --mock --config config_mock.json
```

## Project Structure
```
MPE-Server/
│-- cli/                  # Startup and management scripts
│-- core/                 # Main server logic
│-- communication/        # Communication handling (WebSocket, REST API)
│-- devices/              # Device interfaces (cameras, GPS, etc.)
│-- storage/              # Data storage management
│-- utils/                # Utilities and constants
│-- tests/                # Unit tests
│-- config_mock.json      # Configuration for running with mock
│-- requirements.txt      # Project dependencies
│-- README.md             # This file
```

## Main APIs
The application exposes several REST APIs for:
- Managing photogrammetric datasets
- Controlling camera settings
- Acquiring images and location data

For more details on the APIs, refer to the documentation available in the source code or the Postman collection available [here](https://dr-rd4.postman.co/workspace/3DR-R%26D-Workspace~b0d2457d-0977-4d97-837e-8d2e55398567/collection/7292954-f39db98e-5694-437b-897d-dffa3ccf6dc4?action=share&creator=7292954&active-environment=7292954-d9c440bb-fbb7-46da-bdd0-7dcadd2e4649).